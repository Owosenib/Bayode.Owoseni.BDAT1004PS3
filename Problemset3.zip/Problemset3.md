```python
QUESTION 1
```


```python
SOLUTION
```


```python
Step 1
```


```python
#importing the necessary libararies
import pandas as pd  
import numpy as np
```


```python
Step 2 (# Import the dataset from this address)
```


```python
url = 'https://raw.githubusercontent.com/justmarkham/DAT8/master/data/u.user'
```


```python
Step 3 (#Assign it to a variable called users)
```


```python
users = pd.read_csv('https://raw.githubusercontent.com/justmarkham/DAT8/master/data/u.user', sep = '|')
```


```python
users.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>age</th>
      <th>gender</th>
      <th>occupation</th>
      <th>zip_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>24</td>
      <td>M</td>
      <td>technician</td>
      <td>85711</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>53</td>
      <td>F</td>
      <td>other</td>
      <td>94043</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>23</td>
      <td>M</td>
      <td>writer</td>
      <td>32067</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>24</td>
      <td>M</td>
      <td>technician</td>
      <td>43537</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>33</td>
      <td>F</td>
      <td>other</td>
      <td>15213</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 4 (#Discover what is the mean age per occupation)
```


```python
users.groupby('occupation')['age'].mean()
```




    occupation
    administrator    38.746835
    artist           31.392857
    doctor           43.571429
    educator         42.010526
    engineer         36.388060
    entertainment    29.222222
    executive        38.718750
    healthcare       41.562500
    homemaker        32.571429
    lawyer           36.750000
    librarian        40.000000
    marketing        37.615385
    none             26.555556
    other            34.523810
    programmer       33.121212
    retired          63.071429
    salesman         35.666667
    scientist        35.548387
    student          22.081633
    technician       33.148148
    writer           36.311111
    Name: age, dtype: float64




```python
Step 5 (#Discover the Male ratio per occupation and sort it from the most to the least)
```


```python
users.gender.apply(lambda X: True if X =='M' else False)
```




    0       True
    1      False
    2       True
    3       True
    4      False
           ...  
    938    False
    939     True
    940     True
    941    False
    942     True
    Name: gender, Length: 943, dtype: bool




```python
(users.groupby('occupation').is_male.sum() / users.groupby('occupation').gender.count()).sort_values(ascending = False)
```


```python
Step 6 (#For each occupation, calculate the minimum and maximum ages)
```


```python
print(users.groupby('occupation').age.min())
print(users.groupby('occupation').age.max())
```

    occupation
    administrator    21
    artist           19
    doctor           28
    educator         23
    engineer         22
    entertainment    15
    executive        22
    healthcare       22
    homemaker        20
    lawyer           21
    librarian        23
    marketing        24
    none             11
    other            13
    programmer       20
    retired          51
    salesman         18
    scientist        23
    student           7
    technician       21
    writer           18
    Name: age, dtype: int64
    occupation
    administrator    70
    artist           48
    doctor           64
    educator         63
    engineer         70
    entertainment    50
    executive        69
    healthcare       62
    homemaker        50
    lawyer           53
    librarian        69
    marketing        55
    none             55
    other            64
    programmer       63
    retired          73
    salesman         66
    scientist        55
    student          42
    technician       55
    writer           60
    Name: age, dtype: int64
    


```python
users.groupby('occupation').age.agg(['min', 'max'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>min</th>
      <th>max</th>
    </tr>
    <tr>
      <th>occupation</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>administrator</th>
      <td>21</td>
      <td>70</td>
    </tr>
    <tr>
      <th>artist</th>
      <td>19</td>
      <td>48</td>
    </tr>
    <tr>
      <th>doctor</th>
      <td>28</td>
      <td>64</td>
    </tr>
    <tr>
      <th>educator</th>
      <td>23</td>
      <td>63</td>
    </tr>
    <tr>
      <th>engineer</th>
      <td>22</td>
      <td>70</td>
    </tr>
    <tr>
      <th>entertainment</th>
      <td>15</td>
      <td>50</td>
    </tr>
    <tr>
      <th>executive</th>
      <td>22</td>
      <td>69</td>
    </tr>
    <tr>
      <th>healthcare</th>
      <td>22</td>
      <td>62</td>
    </tr>
    <tr>
      <th>homemaker</th>
      <td>20</td>
      <td>50</td>
    </tr>
    <tr>
      <th>lawyer</th>
      <td>21</td>
      <td>53</td>
    </tr>
    <tr>
      <th>librarian</th>
      <td>23</td>
      <td>69</td>
    </tr>
    <tr>
      <th>marketing</th>
      <td>24</td>
      <td>55</td>
    </tr>
    <tr>
      <th>none</th>
      <td>11</td>
      <td>55</td>
    </tr>
    <tr>
      <th>other</th>
      <td>13</td>
      <td>64</td>
    </tr>
    <tr>
      <th>programmer</th>
      <td>20</td>
      <td>63</td>
    </tr>
    <tr>
      <th>retired</th>
      <td>51</td>
      <td>73</td>
    </tr>
    <tr>
      <th>salesman</th>
      <td>18</td>
      <td>66</td>
    </tr>
    <tr>
      <th>scientist</th>
      <td>23</td>
      <td>55</td>
    </tr>
    <tr>
      <th>student</th>
      <td>7</td>
      <td>42</td>
    </tr>
    <tr>
      <th>technician</th>
      <td>21</td>
      <td>55</td>
    </tr>
    <tr>
      <th>writer</th>
      <td>18</td>
      <td>60</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 7 (#For each combination of occupation and sex, calculate the mean age)
```


```python
users.groupby(['occupation' , 'gender']).age.mean()
```




    occupation     gender
    administrator  F         40.638889
                   M         37.162791
    artist         F         30.307692
                   M         32.333333
    doctor         M         43.571429
    educator       F         39.115385
                   M         43.101449
    engineer       F         29.500000
                   M         36.600000
    entertainment  F         31.000000
                   M         29.000000
    executive      F         44.000000
                   M         38.172414
    healthcare     F         39.818182
                   M         45.400000
    homemaker      F         34.166667
                   M         23.000000
    lawyer         F         39.500000
                   M         36.200000
    librarian      F         40.000000
                   M         40.000000
    marketing      F         37.200000
                   M         37.875000
    none           F         36.500000
                   M         18.600000
    other          F         35.472222
                   M         34.028986
    programmer     F         32.166667
                   M         33.216667
    retired        F         70.000000
                   M         62.538462
    salesman       F         27.000000
                   M         38.555556
    scientist      F         28.333333
                   M         36.321429
    student        F         20.750000
                   M         22.669118
    technician     F         38.000000
                   M         32.961538
    writer         F         37.631579
                   M         35.346154
    Name: age, dtype: float64




```python
Step 8 (#For each occupation present the percentage of women and men)
```


```python
#I will first create a dataframe and apply count to gender
gender_occup = users.groupby(['occupation' , 'gender']).agg({'gender' : 'count'})
```


```python
#next , i will create another dataframe and apply count for each occupation
occup_count = users.groupby(['occupation']).count()
```


```python
#finally, i now divide gender_occup by the occup_count and multiply by 100
occup_gender = gender_occup.div(occup_count , level = "occupation")
occup_gender.loc[:, 'gender']
```




    occupation     gender
    administrator  F         0.455696
                   M         0.544304
    artist         F         0.464286
                   M         0.535714
    doctor         M         1.000000
    educator       F         0.273684
                   M         0.726316
    engineer       F         0.029851
                   M         0.970149
    entertainment  F         0.111111
                   M         0.888889
    executive      F         0.093750
                   M         0.906250
    healthcare     F         0.687500
                   M         0.312500
    homemaker      F         0.857143
                   M         0.142857
    lawyer         F         0.166667
                   M         0.833333
    librarian      F         0.568627
                   M         0.431373
    marketing      F         0.384615
                   M         0.615385
    none           F         0.444444
                   M         0.555556
    other          F         0.342857
                   M         0.657143
    programmer     F         0.090909
                   M         0.909091
    retired        F         0.071429
                   M         0.928571
    salesman       F         0.250000
                   M         0.750000
    scientist      F         0.096774
                   M         0.903226
    student        F         0.306122
                   M         0.693878
    technician     F         0.037037
                   M         0.962963
    writer         F         0.422222
                   M         0.577778
    Name: gender, dtype: float64




```python

```


```python
QUESTION 2
```


```python
SOLUTION
```


```python
Step 1(#import the necessary library)
```


```python
import pandas as pd
```


```python
Step 2 (#Import the dataset from this address)
```


```python
url = 'https://raw.githubusercontent.com/guipsamora/pandas_exercises/master/02_Filtering_%26_Sorting/Euro12/Euro_2012_stats_TEAM.csv'
```


```python
Step 3 (#. Assign it to a variable called euro12)
```


```python
euro12 = pd.read_csv('https://raw.githubusercontent.com/guipsamora/pandas_exercises/master/02_Filtering_%26_Sorting/Euro12/Euro_2012_stats_TEAM.csv')
```


```python
euro12.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Goals</th>
      <th>Shots on target</th>
      <th>Shots off target</th>
      <th>Shooting Accuracy</th>
      <th>% Goals-to-shots</th>
      <th>Total shots (inc. Blocked)</th>
      <th>Hit Woodwork</th>
      <th>Penalty goals</th>
      <th>Penalties not scored</th>
      <th>...</th>
      <th>Saves made</th>
      <th>Saves-to-shots ratio</th>
      <th>Fouls Won</th>
      <th>Fouls Conceded</th>
      <th>Offsides</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
      <th>Subs on</th>
      <th>Subs off</th>
      <th>Players Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Croatia</td>
      <td>4</td>
      <td>13</td>
      <td>12</td>
      <td>51.9%</td>
      <td>16.0%</td>
      <td>32</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>13</td>
      <td>81.3%</td>
      <td>41</td>
      <td>62</td>
      <td>2</td>
      <td>9</td>
      <td>0</td>
      <td>9</td>
      <td>9</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Czech Republic</td>
      <td>4</td>
      <td>13</td>
      <td>18</td>
      <td>41.9%</td>
      <td>12.9%</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>9</td>
      <td>60.1%</td>
      <td>53</td>
      <td>73</td>
      <td>8</td>
      <td>7</td>
      <td>0</td>
      <td>11</td>
      <td>11</td>
      <td>19</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>4</td>
      <td>10</td>
      <td>10</td>
      <td>50.0%</td>
      <td>20.0%</td>
      <td>27</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>10</td>
      <td>66.7%</td>
      <td>25</td>
      <td>38</td>
      <td>8</td>
      <td>4</td>
      <td>0</td>
      <td>7</td>
      <td>7</td>
      <td>15</td>
    </tr>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>5</td>
      <td>11</td>
      <td>18</td>
      <td>50.0%</td>
      <td>17.2%</td>
      <td>40</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>22</td>
      <td>88.1%</td>
      <td>43</td>
      <td>45</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>11</td>
      <td>11</td>
      <td>16</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>3</td>
      <td>22</td>
      <td>24</td>
      <td>37.9%</td>
      <td>6.5%</td>
      <td>65</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>6</td>
      <td>54.6%</td>
      <td>36</td>
      <td>51</td>
      <td>5</td>
      <td>6</td>
      <td>0</td>
      <td>11</td>
      <td>11</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 35 columns</p>
</div>




```python
Step 4 (#Select only the Goal column)
```


```python
euro12['Goals']
```




    0      4
    1      4
    2      4
    3      5
    4      3
    5     10
    6      5
    7      6
    8      2
    9      2
    10     6
    11     1
    12     5
    13    12
    14     5
    15     2
    Name: Goals, dtype: int64




```python
Step 5 (#How many team participated in the Euro2012?)
```


```python
len(euro12['Team'].unique())
```




    16




```python
Step 6 (#What is the number of columns in the dataset?)
```


```python
len(euro12.columns)
```




    35




```python
Step 7 (#View only the columns Team, Yellow Cards and Red Cards and assign them to a dataframe called discipline)
```


```python
discipline = euro12[['Team','Yellow Cards','Red Cards']]
```


```python
discipline.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Croatia</td>
      <td>9</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Czech Republic</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>6</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 8 (#Sort the teams by Red Cards, then to Yellow Cards)
```


```python
discipline.sort_values(['Red Cards','Yellow Cards'], ascending=[True, True])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Germany</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Netherlands</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ukraine</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Russia</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Czech Republic</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Sweden</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Croatia</td>
      <td>9</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Spain</td>
      <td>11</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Portugal</td>
      <td>12</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Italy</td>
      <td>16</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Republic of Ireland</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Poland</td>
      <td>7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Greece</td>
      <td>9</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step  9 (#Calculate the mean Yellow Cards given per Team)
```


```python
discipline.groupby('Team')['Yellow Cards'].mean()
```




    Team
    Croatia                 9.0
    Czech Republic          7.0
    Denmark                 4.0
    England                 5.0
    France                  6.0
    Germany                 4.0
    Greece                  9.0
    Italy                  16.0
    Netherlands             5.0
    Poland                  7.0
    Portugal               12.0
    Republic of Ireland     6.0
    Russia                  6.0
    Spain                  11.0
    Sweden                  7.0
    Ukraine                 5.0
    Name: Yellow Cards, dtype: float64




```python
Step 10 (#Filter teams that scored more than 6 goals)
```


```python
euro12[euro12.Goals > 6]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Goals</th>
      <th>Shots on target</th>
      <th>Shots off target</th>
      <th>Shooting Accuracy</th>
      <th>% Goals-to-shots</th>
      <th>Total shots (inc. Blocked)</th>
      <th>Hit Woodwork</th>
      <th>Penalty goals</th>
      <th>Penalties not scored</th>
      <th>...</th>
      <th>Saves made</th>
      <th>Saves-to-shots ratio</th>
      <th>Fouls Won</th>
      <th>Fouls Conceded</th>
      <th>Offsides</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
      <th>Subs on</th>
      <th>Subs off</th>
      <th>Players Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>Germany</td>
      <td>10</td>
      <td>32</td>
      <td>32</td>
      <td>47.8%</td>
      <td>15.6%</td>
      <td>80</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>10</td>
      <td>62.6%</td>
      <td>63</td>
      <td>49</td>
      <td>12</td>
      <td>4</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
      <td>17</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Spain</td>
      <td>12</td>
      <td>42</td>
      <td>33</td>
      <td>55.9%</td>
      <td>16.0%</td>
      <td>100</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>15</td>
      <td>93.8%</td>
      <td>102</td>
      <td>83</td>
      <td>19</td>
      <td>11</td>
      <td>0</td>
      <td>17</td>
      <td>17</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 35 columns</p>
</div>




```python
Step 11 (#Select the teams that start with G)
```


```python
euro12[euro12.Team.str[0] == 'G']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Goals</th>
      <th>Shots on target</th>
      <th>Shots off target</th>
      <th>Shooting Accuracy</th>
      <th>% Goals-to-shots</th>
      <th>Total shots (inc. Blocked)</th>
      <th>Hit Woodwork</th>
      <th>Penalty goals</th>
      <th>Penalties not scored</th>
      <th>...</th>
      <th>Saves made</th>
      <th>Saves-to-shots ratio</th>
      <th>Fouls Won</th>
      <th>Fouls Conceded</th>
      <th>Offsides</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
      <th>Subs on</th>
      <th>Subs off</th>
      <th>Players Used</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>Germany</td>
      <td>10</td>
      <td>32</td>
      <td>32</td>
      <td>47.8%</td>
      <td>15.6%</td>
      <td>80</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>10</td>
      <td>62.6%</td>
      <td>63</td>
      <td>49</td>
      <td>12</td>
      <td>4</td>
      <td>0</td>
      <td>15</td>
      <td>15</td>
      <td>17</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Greece</td>
      <td>5</td>
      <td>8</td>
      <td>18</td>
      <td>30.7%</td>
      <td>19.2%</td>
      <td>32</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>13</td>
      <td>65.1%</td>
      <td>67</td>
      <td>48</td>
      <td>12</td>
      <td>9</td>
      <td>1</td>
      <td>12</td>
      <td>12</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 35 columns</p>
</div>




```python
Step 12 (# Select the first 7 columns)
```


```python
euro12.iloc[: , 0:7]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Goals</th>
      <th>Shots on target</th>
      <th>Shots off target</th>
      <th>Shooting Accuracy</th>
      <th>% Goals-to-shots</th>
      <th>Total shots (inc. Blocked)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Croatia</td>
      <td>4</td>
      <td>13</td>
      <td>12</td>
      <td>51.9%</td>
      <td>16.0%</td>
      <td>32</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Czech Republic</td>
      <td>4</td>
      <td>13</td>
      <td>18</td>
      <td>41.9%</td>
      <td>12.9%</td>
      <td>39</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>4</td>
      <td>10</td>
      <td>10</td>
      <td>50.0%</td>
      <td>20.0%</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>5</td>
      <td>11</td>
      <td>18</td>
      <td>50.0%</td>
      <td>17.2%</td>
      <td>40</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>3</td>
      <td>22</td>
      <td>24</td>
      <td>37.9%</td>
      <td>6.5%</td>
      <td>65</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Germany</td>
      <td>10</td>
      <td>32</td>
      <td>32</td>
      <td>47.8%</td>
      <td>15.6%</td>
      <td>80</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Greece</td>
      <td>5</td>
      <td>8</td>
      <td>18</td>
      <td>30.7%</td>
      <td>19.2%</td>
      <td>32</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Italy</td>
      <td>6</td>
      <td>34</td>
      <td>45</td>
      <td>43.0%</td>
      <td>7.5%</td>
      <td>110</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Netherlands</td>
      <td>2</td>
      <td>12</td>
      <td>36</td>
      <td>25.0%</td>
      <td>4.1%</td>
      <td>60</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Poland</td>
      <td>2</td>
      <td>15</td>
      <td>23</td>
      <td>39.4%</td>
      <td>5.2%</td>
      <td>48</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Portugal</td>
      <td>6</td>
      <td>22</td>
      <td>42</td>
      <td>34.3%</td>
      <td>9.3%</td>
      <td>82</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Republic of Ireland</td>
      <td>1</td>
      <td>7</td>
      <td>12</td>
      <td>36.8%</td>
      <td>5.2%</td>
      <td>28</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Russia</td>
      <td>5</td>
      <td>9</td>
      <td>31</td>
      <td>22.5%</td>
      <td>12.5%</td>
      <td>59</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Spain</td>
      <td>12</td>
      <td>42</td>
      <td>33</td>
      <td>55.9%</td>
      <td>16.0%</td>
      <td>100</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Sweden</td>
      <td>5</td>
      <td>17</td>
      <td>19</td>
      <td>47.2%</td>
      <td>13.8%</td>
      <td>39</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ukraine</td>
      <td>2</td>
      <td>7</td>
      <td>26</td>
      <td>21.2%</td>
      <td>6.0%</td>
      <td>38</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 13 (#Select all columns except the last 3)
```


```python
euro12.iloc[: , :-3]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Goals</th>
      <th>Shots on target</th>
      <th>Shots off target</th>
      <th>Shooting Accuracy</th>
      <th>% Goals-to-shots</th>
      <th>Total shots (inc. Blocked)</th>
      <th>Hit Woodwork</th>
      <th>Penalty goals</th>
      <th>Penalties not scored</th>
      <th>...</th>
      <th>Clean Sheets</th>
      <th>Blocks</th>
      <th>Goals conceded</th>
      <th>Saves made</th>
      <th>Saves-to-shots ratio</th>
      <th>Fouls Won</th>
      <th>Fouls Conceded</th>
      <th>Offsides</th>
      <th>Yellow Cards</th>
      <th>Red Cards</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Croatia</td>
      <td>4</td>
      <td>13</td>
      <td>12</td>
      <td>51.9%</td>
      <td>16.0%</td>
      <td>32</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>10</td>
      <td>3</td>
      <td>13</td>
      <td>81.3%</td>
      <td>41</td>
      <td>62</td>
      <td>2</td>
      <td>9</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Czech Republic</td>
      <td>4</td>
      <td>13</td>
      <td>18</td>
      <td>41.9%</td>
      <td>12.9%</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>10</td>
      <td>6</td>
      <td>9</td>
      <td>60.1%</td>
      <td>53</td>
      <td>73</td>
      <td>8</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>4</td>
      <td>10</td>
      <td>10</td>
      <td>50.0%</td>
      <td>20.0%</td>
      <td>27</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>10</td>
      <td>5</td>
      <td>10</td>
      <td>66.7%</td>
      <td>25</td>
      <td>38</td>
      <td>8</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>5</td>
      <td>11</td>
      <td>18</td>
      <td>50.0%</td>
      <td>17.2%</td>
      <td>40</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>29</td>
      <td>3</td>
      <td>22</td>
      <td>88.1%</td>
      <td>43</td>
      <td>45</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>3</td>
      <td>22</td>
      <td>24</td>
      <td>37.9%</td>
      <td>6.5%</td>
      <td>65</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>7</td>
      <td>5</td>
      <td>6</td>
      <td>54.6%</td>
      <td>36</td>
      <td>51</td>
      <td>5</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Germany</td>
      <td>10</td>
      <td>32</td>
      <td>32</td>
      <td>47.8%</td>
      <td>15.6%</td>
      <td>80</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>11</td>
      <td>6</td>
      <td>10</td>
      <td>62.6%</td>
      <td>63</td>
      <td>49</td>
      <td>12</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Greece</td>
      <td>5</td>
      <td>8</td>
      <td>18</td>
      <td>30.7%</td>
      <td>19.2%</td>
      <td>32</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>23</td>
      <td>7</td>
      <td>13</td>
      <td>65.1%</td>
      <td>67</td>
      <td>48</td>
      <td>12</td>
      <td>9</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Italy</td>
      <td>6</td>
      <td>34</td>
      <td>45</td>
      <td>43.0%</td>
      <td>7.5%</td>
      <td>110</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>18</td>
      <td>7</td>
      <td>20</td>
      <td>74.1%</td>
      <td>101</td>
      <td>89</td>
      <td>16</td>
      <td>16</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Netherlands</td>
      <td>2</td>
      <td>12</td>
      <td>36</td>
      <td>25.0%</td>
      <td>4.1%</td>
      <td>60</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>9</td>
      <td>5</td>
      <td>12</td>
      <td>70.6%</td>
      <td>35</td>
      <td>30</td>
      <td>3</td>
      <td>5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Poland</td>
      <td>2</td>
      <td>15</td>
      <td>23</td>
      <td>39.4%</td>
      <td>5.2%</td>
      <td>48</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>6</td>
      <td>66.7%</td>
      <td>48</td>
      <td>56</td>
      <td>3</td>
      <td>7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Portugal</td>
      <td>6</td>
      <td>22</td>
      <td>42</td>
      <td>34.3%</td>
      <td>9.3%</td>
      <td>82</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>2</td>
      <td>11</td>
      <td>4</td>
      <td>10</td>
      <td>71.5%</td>
      <td>73</td>
      <td>90</td>
      <td>10</td>
      <td>12</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Republic of Ireland</td>
      <td>1</td>
      <td>7</td>
      <td>12</td>
      <td>36.8%</td>
      <td>5.2%</td>
      <td>28</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>23</td>
      <td>9</td>
      <td>17</td>
      <td>65.4%</td>
      <td>43</td>
      <td>51</td>
      <td>11</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Russia</td>
      <td>5</td>
      <td>9</td>
      <td>31</td>
      <td>22.5%</td>
      <td>12.5%</td>
      <td>59</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>10</td>
      <td>77.0%</td>
      <td>34</td>
      <td>43</td>
      <td>4</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Spain</td>
      <td>12</td>
      <td>42</td>
      <td>33</td>
      <td>55.9%</td>
      <td>16.0%</td>
      <td>100</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>5</td>
      <td>8</td>
      <td>1</td>
      <td>15</td>
      <td>93.8%</td>
      <td>102</td>
      <td>83</td>
      <td>19</td>
      <td>11</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Sweden</td>
      <td>5</td>
      <td>17</td>
      <td>19</td>
      <td>47.2%</td>
      <td>13.8%</td>
      <td>39</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>12</td>
      <td>5</td>
      <td>8</td>
      <td>61.6%</td>
      <td>35</td>
      <td>51</td>
      <td>7</td>
      <td>7</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ukraine</td>
      <td>2</td>
      <td>7</td>
      <td>26</td>
      <td>21.2%</td>
      <td>6.0%</td>
      <td>38</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>4</td>
      <td>4</td>
      <td>13</td>
      <td>76.5%</td>
      <td>48</td>
      <td>31</td>
      <td>4</td>
      <td>5</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>16 rows × 32 columns</p>
</div>




```python
Step 14 (#Present only the Shooting Accuracy from England, Italy and Russia)
```


```python
euro12.loc[[3,7,12] , ['Team','Shooting Accuracy']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Team</th>
      <th>Shooting Accuracy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>England</td>
      <td>50.0%</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Italy</td>
      <td>43.0%</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Russia</td>
      <td>22.5%</td>
    </tr>
  </tbody>
</table>
</div>




```python
QUESTION 3
```


```python
SOLUTION
```


```python
Step 1 (#Import the necessary libraries)
```


```python
import pandas as pd
import numpy as np
```


```python
Step 2(#Create 3 differents Series, each of length 100, as follows:

The first a random number from 1 to 4
The second a random number from 1 to 3
The third a random number from 10,000 to 30,000)
```


```python
#Series 1 -The first a random number from 1 to 4
s1 = pd.Series(np.random.randint(1,5, size=(100)))
```


```python
s1.head()
```




    0    4
    1    3
    2    1
    3    4
    4    3
    dtype: int32




```python
#Series 2 - The second a random number from 1 to 3
s2 = pd.Series(np.random.randint(1,4, size=(100)))
```


```python
s2.head()
```




    0    1
    1    1
    2    2
    3    3
    4    1
    dtype: int32




```python
#Seies 3 - The third a random number from 10,000 to 30,000)
s3 = pd.Series(np.random.randint(10000,30001, size=(100)))
```


```python
s3.head()
```




    0    20035
    1    12185
    2    23909
    3    11074
    4    26981
    dtype: int32




```python
Step 3 (#Create a DataFrame by joinning the Series by column)
```


```python
df = pd.DataFrame({'s1':s1,'s2':s2,'s3':s3})
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>s1</th>
      <th>s2</th>
      <th>s3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>1</td>
      <td>20035</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
      <td>12185</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>2</td>
      <td>23909</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>11074</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>1</td>
      <td>26981</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 4 (#Change the name of the columns to bedrs, bathrs, price_sqr_meter)
```


```python
df.rename(columns = {'s1':'bedrs', 's2':'bathrs', 's3':'price_sqr_meter'}, inplace = True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bedrs</th>
      <th>bathrs</th>
      <th>price_sqr_meter</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>1</td>
      <td>20035</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
      <td>12185</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>2</td>
      <td>23909</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>3</td>
      <td>11074</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>1</td>
      <td>26981</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 5 (#Create a one column DataFrame with the values of the 3 Series and assign it to 'bigcolumn' , lets call it new dataframe nd)
```


```python
nd = pd.DataFrame({'bigcolumn': pd.concat([s1, s2, s3])})
```


```python
nd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bigcolumn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 6 (#Ops it seems it is going only until index 99. Is it true?)
```


```python
yes it is true
```


```python
Step 7(#Reindex the DataFrame so it goes from 0 to 299)
```


```python
nd.index = pd.RangeIndex(start=0, stop=300)
```


```python
pd.RangeIndex(start=0, stop=300)
```




    RangeIndex(start=0, stop=300, step=1)




```python
QUESTION 4
```


```python
SOLUTION
```


```python
Step 1 (#Import the necessary libraries)
```


```python
import numpy as np
import pandas as pd
import datetime
```


```python
Step 2 (#Import the dataset from the attached file wind.txt)
```


```python
data = 'https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/12679944?X-Blackboard-Expiration=1650110400000&X-Blackboard-Signature=dgYd1m5K3ktgyNwIB7nZzNdreGD0USfJGBaawsI7XGQ%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27wind.txt&response-content-type=text%2Fplain&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIQCN19bd1Wj9q2z8vE%2FlrwhdsYK9u0%2FOv%2BmuQ6BJ0gLJbwIgbJFsX9jkwFx%2Bd4U%2FhXXFaRsrXmZpY726qRTRXdnxgB8qgwQIoP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw1NTY5MDM4NjEzNjEiDO6bVwzV5u6EIdFmsirXA%2BztS9VM2KyiEHEHSquYpfz5TffnBRWIgJ0SIoiR1kOvNE11%2BGzJQJEATbr6RJR15wzY%2FicQVSBxGHt0KXoeIwovl6%2FZ0TAiucqm6XrFMHChYNfRP9B6mqqhwXtR4tmpkhbKnLYXZ0fcEztKywb%2FGLSC5Y0PHXf4HNEJvA8bv1YaKMNT2z4Rn%2BdJ6vpeO6ieYO9LObFYXRrOuc%2F8qeBKjtorXU6e%2FIcj7cP5fOgzoXppaifUfzTJ73D1VAkYBMIWcWi8btPj2weI84A9yR6HxAy%2BOvFK6cqT2Pw6Fly1DE8pcqB0UFogPOQRcJxGJV3EjLKSjNHOXLRraSEzpEHSwkLUiqE2DMYXnwqupJkHxiDpN3A5%2BCbaURTxzWvwn3m4UBPzOqiyPx4QFzWR2dU4HI%2FJPkrtyF6sOfjPc9waQJrE4AMjwhUR9GHkEx8s4821LpN%2F6WGuNJKkIauJtg49dC%2Bk36yaRF7WVHoIVUyA6nfcZxiFhNkXMIKryNXsEBE%2BRG6z4obUseQdXBGFgD4WGjDFmPjETDFI0pDkczEpzpG0RHN7dygUxs%2FNxHqMXxzbUpKJwAy2CU8fjI%2B2a6D%2BH6TurGy4a6iVttAuMlYXy%2BXCjX9i5DhCnDCr0OmSBjqlAcNGaTo%2FQepvjHL9YIWW1b983aif8kr%2Bq3zK4md%2B3o%2BnMTy73j21rvwdL8oecAcBYMT%2FN%2B9JRT%2BYQbsD7sMiwlKwk2KRaFd86C4bTHqFpDzR9URqw8%2FIPJSxio6Crub%2Bj0HShdTwEspamWFMGCavMqDCirknYFE45Awcz%2B%2FQ8qRdOPsiqBVWnM360xrRIHtwQSrcUfwpMIKPPua%2FYYhVLQaCcgvXzg%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T060000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRY7VY5EMXA%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=37847f84a0421c0bffbe3fc0989b42e27ce27bf46391e0ebcc02e9324a69ad2e'
```


```python
Step 3 (#Assign it to a variable called data and replace the first 3 columns by a proper datetime index.)
```


```python
data = pd.read_csv('https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/12679944?X-Blackboard-Expiration=1650110400000&X-Blackboard-Signature=dgYd1m5K3ktgyNwIB7nZzNdreGD0USfJGBaawsI7XGQ%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27wind.txt&response-content-type=text%2Fplain&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIQCN19bd1Wj9q2z8vE%2FlrwhdsYK9u0%2FOv%2BmuQ6BJ0gLJbwIgbJFsX9jkwFx%2Bd4U%2FhXXFaRsrXmZpY726qRTRXdnxgB8qgwQIoP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw1NTY5MDM4NjEzNjEiDO6bVwzV5u6EIdFmsirXA%2BztS9VM2KyiEHEHSquYpfz5TffnBRWIgJ0SIoiR1kOvNE11%2BGzJQJEATbr6RJR15wzY%2FicQVSBxGHt0KXoeIwovl6%2FZ0TAiucqm6XrFMHChYNfRP9B6mqqhwXtR4tmpkhbKnLYXZ0fcEztKywb%2FGLSC5Y0PHXf4HNEJvA8bv1YaKMNT2z4Rn%2BdJ6vpeO6ieYO9LObFYXRrOuc%2F8qeBKjtorXU6e%2FIcj7cP5fOgzoXppaifUfzTJ73D1VAkYBMIWcWi8btPj2weI84A9yR6HxAy%2BOvFK6cqT2Pw6Fly1DE8pcqB0UFogPOQRcJxGJV3EjLKSjNHOXLRraSEzpEHSwkLUiqE2DMYXnwqupJkHxiDpN3A5%2BCbaURTxzWvwn3m4UBPzOqiyPx4QFzWR2dU4HI%2FJPkrtyF6sOfjPc9waQJrE4AMjwhUR9GHkEx8s4821LpN%2F6WGuNJKkIauJtg49dC%2Bk36yaRF7WVHoIVUyA6nfcZxiFhNkXMIKryNXsEBE%2BRG6z4obUseQdXBGFgD4WGjDFmPjETDFI0pDkczEpzpG0RHN7dygUxs%2FNxHqMXxzbUpKJwAy2CU8fjI%2B2a6D%2BH6TurGy4a6iVttAuMlYXy%2BXCjX9i5DhCnDCr0OmSBjqlAcNGaTo%2FQepvjHL9YIWW1b983aif8kr%2Bq3zK4md%2B3o%2BnMTy73j21rvwdL8oecAcBYMT%2FN%2B9JRT%2BYQbsD7sMiwlKwk2KRaFd86C4bTHqFpDzR9URqw8%2FIPJSxio6Crub%2Bj0HShdTwEspamWFMGCavMqDCirknYFE45Awcz%2B%2FQ8qRdOPsiqBVWnM360xrRIHtwQSrcUfwpMIKPPua%2FYYhVLQaCcgvXzg%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T060000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRY7VY5EMXA%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=37847f84a0421c0bffbe3fc0989b42e27ce27bf46391e0ebcc02e9324a69ad2e',sep="\s+",parse_dates=[[0,1,2]])
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Yr_Mo_Dy</th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2061-01-01</td>
      <td>15.04</td>
      <td>14.96</td>
      <td>13.17</td>
      <td>9.29</td>
      <td>NaN</td>
      <td>9.87</td>
      <td>13.67</td>
      <td>10.25</td>
      <td>10.83</td>
      <td>12.58</td>
      <td>18.50</td>
      <td>15.04</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2061-01-02</td>
      <td>14.71</td>
      <td>NaN</td>
      <td>10.83</td>
      <td>6.50</td>
      <td>12.62</td>
      <td>7.67</td>
      <td>11.50</td>
      <td>10.04</td>
      <td>9.79</td>
      <td>9.67</td>
      <td>17.54</td>
      <td>13.83</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2061-01-03</td>
      <td>18.50</td>
      <td>16.88</td>
      <td>12.33</td>
      <td>10.13</td>
      <td>11.17</td>
      <td>6.17</td>
      <td>11.25</td>
      <td>NaN</td>
      <td>8.50</td>
      <td>7.67</td>
      <td>12.75</td>
      <td>12.71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2061-01-04</td>
      <td>10.58</td>
      <td>6.63</td>
      <td>11.75</td>
      <td>4.58</td>
      <td>4.54</td>
      <td>2.88</td>
      <td>8.63</td>
      <td>1.79</td>
      <td>5.83</td>
      <td>5.88</td>
      <td>5.46</td>
      <td>10.88</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2061-01-05</td>
      <td>13.33</td>
      <td>13.25</td>
      <td>11.42</td>
      <td>6.17</td>
      <td>10.71</td>
      <td>8.21</td>
      <td>11.92</td>
      <td>6.54</td>
      <td>10.92</td>
      <td>10.34</td>
      <td>12.92</td>
      <td>11.83</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 4 (#Year 2061? Do we really have data from this year? Create a function to fix it and apply it.)
```


```python
def fix_century(x):
    year=x.year-100 if x.year > 1979 else x.year
    return datetime.date(year,x.month,x.day)
data['Yr_Mo_Dy']=data['Yr_Mo_Dy'].apply(fix_century)
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Yr_Mo_Dy</th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1961-01-01</td>
      <td>15.04</td>
      <td>14.96</td>
      <td>13.17</td>
      <td>9.29</td>
      <td>NaN</td>
      <td>9.87</td>
      <td>13.67</td>
      <td>10.25</td>
      <td>10.83</td>
      <td>12.58</td>
      <td>18.50</td>
      <td>15.04</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1961-01-02</td>
      <td>14.71</td>
      <td>NaN</td>
      <td>10.83</td>
      <td>6.50</td>
      <td>12.62</td>
      <td>7.67</td>
      <td>11.50</td>
      <td>10.04</td>
      <td>9.79</td>
      <td>9.67</td>
      <td>17.54</td>
      <td>13.83</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1961-01-03</td>
      <td>18.50</td>
      <td>16.88</td>
      <td>12.33</td>
      <td>10.13</td>
      <td>11.17</td>
      <td>6.17</td>
      <td>11.25</td>
      <td>NaN</td>
      <td>8.50</td>
      <td>7.67</td>
      <td>12.75</td>
      <td>12.71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1961-01-04</td>
      <td>10.58</td>
      <td>6.63</td>
      <td>11.75</td>
      <td>4.58</td>
      <td>4.54</td>
      <td>2.88</td>
      <td>8.63</td>
      <td>1.79</td>
      <td>5.83</td>
      <td>5.88</td>
      <td>5.46</td>
      <td>10.88</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1961-01-05</td>
      <td>13.33</td>
      <td>13.25</td>
      <td>11.42</td>
      <td>6.17</td>
      <td>10.71</td>
      <td>8.21</td>
      <td>11.92</td>
      <td>6.54</td>
      <td>10.92</td>
      <td>10.34</td>
      <td>12.92</td>
      <td>11.83</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 5 (#Set the right dates as the index. Pay attention at the data type, it should be datetime64[ns].)
```


```python
data['Yr_Mo_Dy']=pd.to_datetime(data['Yr_Mo_Dy'])
data=data.set_index('Yr_Mo_Dy')
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>15.04</td>
      <td>14.96</td>
      <td>13.17</td>
      <td>9.29</td>
      <td>NaN</td>
      <td>9.87</td>
      <td>13.67</td>
      <td>10.25</td>
      <td>10.83</td>
      <td>12.58</td>
      <td>18.50</td>
      <td>15.04</td>
    </tr>
    <tr>
      <th>1961-01-02</th>
      <td>14.71</td>
      <td>NaN</td>
      <td>10.83</td>
      <td>6.50</td>
      <td>12.62</td>
      <td>7.67</td>
      <td>11.50</td>
      <td>10.04</td>
      <td>9.79</td>
      <td>9.67</td>
      <td>17.54</td>
      <td>13.83</td>
    </tr>
    <tr>
      <th>1961-01-03</th>
      <td>18.50</td>
      <td>16.88</td>
      <td>12.33</td>
      <td>10.13</td>
      <td>11.17</td>
      <td>6.17</td>
      <td>11.25</td>
      <td>NaN</td>
      <td>8.50</td>
      <td>7.67</td>
      <td>12.75</td>
      <td>12.71</td>
    </tr>
    <tr>
      <th>1961-01-04</th>
      <td>10.58</td>
      <td>6.63</td>
      <td>11.75</td>
      <td>4.58</td>
      <td>4.54</td>
      <td>2.88</td>
      <td>8.63</td>
      <td>1.79</td>
      <td>5.83</td>
      <td>5.88</td>
      <td>5.46</td>
      <td>10.88</td>
    </tr>
    <tr>
      <th>1961-01-05</th>
      <td>13.33</td>
      <td>13.25</td>
      <td>11.42</td>
      <td>6.17</td>
      <td>10.71</td>
      <td>8.21</td>
      <td>11.92</td>
      <td>6.54</td>
      <td>10.92</td>
      <td>10.34</td>
      <td>12.92</td>
      <td>11.83</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 6 (#Compute how many values are missing for each location over the entire record.They should be ignored in all calculations below.)
```


```python
data.isnull().sum()
```




    RPT    6
    VAL    3
    ROS    2
    KIL    5
    SHA    2
    BIR    0
    DUB    3
    CLA    2
    MUL    3
    CLO    1
    BEL    0
    MAL    4
    dtype: int64




```python
Step 7 (#Compute how many non-missing values there are in total.)
```


```python
data.shape[0]-data.isnull().sum() 

```




    RPT    6568
    VAL    6571
    ROS    6572
    KIL    6569
    SHA    6572
    BIR    6574
    DUB    6571
    CLA    6572
    MUL    6571
    CLO    6573
    BEL    6574
    MAL    6570
    dtype: int64




```python
Step 8 (#Calculate the mean windspeeds of the windspeeds over all the locations and all the times.)
```


```python
data.mean().mean()
```




    10.227982360836924




```python
Step 9 (#Create a DataFrame called loc_stats and calculate the min, max and mean windspeeds and standard deviations of the windspeeds at each location over all the days)
```


```python
loc_stats=pd.DataFrame()
loc_stats['min']=data.min()
loc_stats['max']=data.max()
loc_stats['mean']=data.mean()
loc_stats['std']=data.std()
loc_stats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>min</th>
      <th>max</th>
      <th>mean</th>
      <th>std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RPT</th>
      <td>0.67</td>
      <td>35.80</td>
      <td>12.362987</td>
      <td>5.618413</td>
    </tr>
    <tr>
      <th>VAL</th>
      <td>0.21</td>
      <td>33.37</td>
      <td>10.644314</td>
      <td>5.267356</td>
    </tr>
    <tr>
      <th>ROS</th>
      <td>1.50</td>
      <td>33.84</td>
      <td>11.660526</td>
      <td>5.008450</td>
    </tr>
    <tr>
      <th>KIL</th>
      <td>0.00</td>
      <td>28.46</td>
      <td>6.306468</td>
      <td>3.605811</td>
    </tr>
    <tr>
      <th>SHA</th>
      <td>0.13</td>
      <td>37.54</td>
      <td>10.455834</td>
      <td>4.936125</td>
    </tr>
    <tr>
      <th>BIR</th>
      <td>0.00</td>
      <td>26.16</td>
      <td>7.092254</td>
      <td>3.968683</td>
    </tr>
    <tr>
      <th>DUB</th>
      <td>0.00</td>
      <td>30.37</td>
      <td>9.797343</td>
      <td>4.977555</td>
    </tr>
    <tr>
      <th>CLA</th>
      <td>0.00</td>
      <td>31.08</td>
      <td>8.495053</td>
      <td>4.499449</td>
    </tr>
    <tr>
      <th>MUL</th>
      <td>0.00</td>
      <td>25.88</td>
      <td>8.493590</td>
      <td>4.166872</td>
    </tr>
    <tr>
      <th>CLO</th>
      <td>0.04</td>
      <td>28.21</td>
      <td>8.707332</td>
      <td>4.503954</td>
    </tr>
    <tr>
      <th>BEL</th>
      <td>0.13</td>
      <td>42.38</td>
      <td>13.121007</td>
      <td>5.835037</td>
    </tr>
    <tr>
      <th>MAL</th>
      <td>0.67</td>
      <td>42.54</td>
      <td>15.599079</td>
      <td>6.699794</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 10 (#Create a DataFrame called day_stats and calculate the min, max and mean windspeed and standard deviations of the windspeeds across all the locations at each day.)
```


```python
day_stats=pd.DataFrame()
day_stats['min']=data.min(axis=1)
day_stats['max']=data.max(axis=1)
day_stats['mean']=data.mean(axis=1)
day_stats['std']=data.std(axis=1)

day_stats.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>min</th>
      <th>max</th>
      <th>mean</th>
      <th>std</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>9.29</td>
      <td>18.50</td>
      <td>13.018182</td>
      <td>2.808875</td>
    </tr>
    <tr>
      <th>1961-01-02</th>
      <td>6.50</td>
      <td>17.54</td>
      <td>11.336364</td>
      <td>3.188994</td>
    </tr>
    <tr>
      <th>1961-01-03</th>
      <td>6.17</td>
      <td>18.50</td>
      <td>11.641818</td>
      <td>3.681912</td>
    </tr>
    <tr>
      <th>1961-01-04</th>
      <td>1.79</td>
      <td>11.75</td>
      <td>6.619167</td>
      <td>3.198126</td>
    </tr>
    <tr>
      <th>1961-01-05</th>
      <td>6.17</td>
      <td>13.33</td>
      <td>10.630000</td>
      <td>2.445356</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 11 (#Find the average windspeed in January for each location.

#Treat January 1961 and January 1962 both as January)
```


```python
data['date']=data.index
data['month']=data['date'].apply(lambda date:date.month)
data['year']=data['date'].apply(lambda date:date.year)
data['day']=data['date'].apply(lambda date:date.day)
january_winds=data.query('month==1')
january_winds
january_winds.loc[:,'RPT':'MAL'].mean()
```




    RPT    14.847325
    VAL    12.914560
    ROS    13.299624
    KIL     7.199498
    SHA    11.667734
    BIR     8.054839
    DUB    11.819355
    CLA     9.512047
    MUL     9.543208
    CLO    10.053566
    BEL    14.550520
    MAL    18.028763
    dtype: float64




```python
Step 12 (#Downsample the record to a yearly frequency for each location.)
```


```python
data.query('month == 1 and day == 1') 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
      <th>date</th>
      <th>month</th>
      <th>year</th>
      <th>day</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>15.04</td>
      <td>14.96</td>
      <td>13.17</td>
      <td>9.29</td>
      <td>NaN</td>
      <td>9.87</td>
      <td>13.67</td>
      <td>10.25</td>
      <td>10.83</td>
      <td>12.58</td>
      <td>18.50</td>
      <td>15.04</td>
      <td>1961-01-01</td>
      <td>1</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1962-01-01</th>
      <td>9.29</td>
      <td>3.42</td>
      <td>11.54</td>
      <td>3.50</td>
      <td>2.21</td>
      <td>1.96</td>
      <td>10.41</td>
      <td>2.79</td>
      <td>3.54</td>
      <td>5.17</td>
      <td>4.38</td>
      <td>7.92</td>
      <td>1962-01-01</td>
      <td>1</td>
      <td>1962</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1963-01-01</th>
      <td>15.59</td>
      <td>13.62</td>
      <td>19.79</td>
      <td>8.38</td>
      <td>12.25</td>
      <td>10.00</td>
      <td>23.45</td>
      <td>15.71</td>
      <td>13.59</td>
      <td>14.37</td>
      <td>17.58</td>
      <td>34.13</td>
      <td>1963-01-01</td>
      <td>1</td>
      <td>1963</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1964-01-01</th>
      <td>25.80</td>
      <td>22.13</td>
      <td>18.21</td>
      <td>13.25</td>
      <td>21.29</td>
      <td>14.79</td>
      <td>14.12</td>
      <td>19.58</td>
      <td>13.25</td>
      <td>16.75</td>
      <td>28.96</td>
      <td>21.00</td>
      <td>1964-01-01</td>
      <td>1</td>
      <td>1964</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1965-01-01</th>
      <td>9.54</td>
      <td>11.92</td>
      <td>9.00</td>
      <td>4.38</td>
      <td>6.08</td>
      <td>5.21</td>
      <td>10.25</td>
      <td>6.08</td>
      <td>5.71</td>
      <td>8.63</td>
      <td>12.04</td>
      <td>17.41</td>
      <td>1965-01-01</td>
      <td>1</td>
      <td>1965</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1966-01-01</th>
      <td>22.04</td>
      <td>21.50</td>
      <td>17.08</td>
      <td>12.75</td>
      <td>22.17</td>
      <td>15.59</td>
      <td>21.79</td>
      <td>18.12</td>
      <td>16.66</td>
      <td>17.83</td>
      <td>28.33</td>
      <td>23.79</td>
      <td>1966-01-01</td>
      <td>1</td>
      <td>1966</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1967-01-01</th>
      <td>6.46</td>
      <td>4.46</td>
      <td>6.50</td>
      <td>3.21</td>
      <td>6.67</td>
      <td>3.79</td>
      <td>11.38</td>
      <td>3.83</td>
      <td>7.71</td>
      <td>9.08</td>
      <td>10.67</td>
      <td>20.91</td>
      <td>1967-01-01</td>
      <td>1</td>
      <td>1967</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1968-01-01</th>
      <td>30.04</td>
      <td>17.88</td>
      <td>16.25</td>
      <td>16.25</td>
      <td>21.79</td>
      <td>12.54</td>
      <td>18.16</td>
      <td>16.62</td>
      <td>18.75</td>
      <td>17.62</td>
      <td>22.25</td>
      <td>27.29</td>
      <td>1968-01-01</td>
      <td>1</td>
      <td>1968</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1969-01-01</th>
      <td>6.13</td>
      <td>1.63</td>
      <td>5.41</td>
      <td>1.08</td>
      <td>2.54</td>
      <td>1.00</td>
      <td>8.50</td>
      <td>2.42</td>
      <td>4.58</td>
      <td>6.34</td>
      <td>9.17</td>
      <td>16.71</td>
      <td>1969-01-01</td>
      <td>1</td>
      <td>1969</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1970-01-01</th>
      <td>9.59</td>
      <td>2.96</td>
      <td>11.79</td>
      <td>3.42</td>
      <td>6.13</td>
      <td>4.08</td>
      <td>9.00</td>
      <td>4.46</td>
      <td>7.29</td>
      <td>3.50</td>
      <td>7.33</td>
      <td>13.00</td>
      <td>1970-01-01</td>
      <td>1</td>
      <td>1970</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1971-01-01</th>
      <td>3.71</td>
      <td>0.79</td>
      <td>4.71</td>
      <td>0.17</td>
      <td>1.42</td>
      <td>1.04</td>
      <td>4.63</td>
      <td>0.75</td>
      <td>1.54</td>
      <td>1.08</td>
      <td>4.21</td>
      <td>9.54</td>
      <td>1971-01-01</td>
      <td>1</td>
      <td>1971</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1972-01-01</th>
      <td>9.29</td>
      <td>3.63</td>
      <td>14.54</td>
      <td>4.25</td>
      <td>6.75</td>
      <td>4.42</td>
      <td>13.00</td>
      <td>5.33</td>
      <td>10.04</td>
      <td>8.54</td>
      <td>8.71</td>
      <td>19.17</td>
      <td>1972-01-01</td>
      <td>1</td>
      <td>1972</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1973-01-01</th>
      <td>16.50</td>
      <td>15.92</td>
      <td>14.62</td>
      <td>7.41</td>
      <td>8.29</td>
      <td>11.21</td>
      <td>13.54</td>
      <td>7.79</td>
      <td>10.46</td>
      <td>10.79</td>
      <td>13.37</td>
      <td>9.71</td>
      <td>1973-01-01</td>
      <td>1</td>
      <td>1973</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1974-01-01</th>
      <td>23.21</td>
      <td>16.54</td>
      <td>16.08</td>
      <td>9.75</td>
      <td>15.83</td>
      <td>11.46</td>
      <td>9.54</td>
      <td>13.54</td>
      <td>13.83</td>
      <td>16.66</td>
      <td>17.21</td>
      <td>25.29</td>
      <td>1974-01-01</td>
      <td>1</td>
      <td>1974</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1975-01-01</th>
      <td>14.04</td>
      <td>13.54</td>
      <td>11.29</td>
      <td>5.46</td>
      <td>12.58</td>
      <td>5.58</td>
      <td>8.12</td>
      <td>8.96</td>
      <td>9.29</td>
      <td>5.17</td>
      <td>7.71</td>
      <td>11.63</td>
      <td>1975-01-01</td>
      <td>1</td>
      <td>1975</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1976-01-01</th>
      <td>18.34</td>
      <td>17.67</td>
      <td>14.83</td>
      <td>8.00</td>
      <td>16.62</td>
      <td>10.13</td>
      <td>13.17</td>
      <td>9.04</td>
      <td>13.13</td>
      <td>5.75</td>
      <td>11.38</td>
      <td>14.96</td>
      <td>1976-01-01</td>
      <td>1</td>
      <td>1976</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1977-01-01</th>
      <td>20.04</td>
      <td>11.92</td>
      <td>20.25</td>
      <td>9.13</td>
      <td>9.29</td>
      <td>8.04</td>
      <td>10.75</td>
      <td>5.88</td>
      <td>9.00</td>
      <td>9.00</td>
      <td>14.88</td>
      <td>25.70</td>
      <td>1977-01-01</td>
      <td>1</td>
      <td>1977</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1978-01-01</th>
      <td>8.33</td>
      <td>7.12</td>
      <td>7.71</td>
      <td>3.54</td>
      <td>8.50</td>
      <td>7.50</td>
      <td>14.71</td>
      <td>10.00</td>
      <td>11.83</td>
      <td>10.00</td>
      <td>15.09</td>
      <td>20.46</td>
      <td>1978-01-01</td>
      <td>1</td>
      <td>1978</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 13 (#Downsample the record to a monthly frequency for each location.)
```


```python
data.query('day == 1')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
      <th>date</th>
      <th>month</th>
      <th>year</th>
      <th>day</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>15.04</td>
      <td>14.96</td>
      <td>13.17</td>
      <td>9.29</td>
      <td>NaN</td>
      <td>9.87</td>
      <td>13.67</td>
      <td>10.25</td>
      <td>10.83</td>
      <td>12.58</td>
      <td>18.50</td>
      <td>15.04</td>
      <td>1961-01-01</td>
      <td>1</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1961-02-01</th>
      <td>14.25</td>
      <td>15.12</td>
      <td>9.04</td>
      <td>5.88</td>
      <td>12.08</td>
      <td>7.17</td>
      <td>10.17</td>
      <td>3.63</td>
      <td>6.50</td>
      <td>5.50</td>
      <td>9.17</td>
      <td>8.00</td>
      <td>1961-02-01</td>
      <td>2</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1961-03-01</th>
      <td>12.67</td>
      <td>13.13</td>
      <td>11.79</td>
      <td>6.42</td>
      <td>9.79</td>
      <td>8.54</td>
      <td>10.25</td>
      <td>13.29</td>
      <td>NaN</td>
      <td>12.21</td>
      <td>20.62</td>
      <td>NaN</td>
      <td>1961-03-01</td>
      <td>3</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1961-04-01</th>
      <td>8.38</td>
      <td>6.34</td>
      <td>8.33</td>
      <td>6.75</td>
      <td>9.33</td>
      <td>9.54</td>
      <td>11.67</td>
      <td>8.21</td>
      <td>11.21</td>
      <td>6.46</td>
      <td>11.96</td>
      <td>7.17</td>
      <td>1961-04-01</td>
      <td>4</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1961-05-01</th>
      <td>15.87</td>
      <td>13.88</td>
      <td>15.37</td>
      <td>9.79</td>
      <td>13.46</td>
      <td>10.17</td>
      <td>9.96</td>
      <td>14.04</td>
      <td>9.75</td>
      <td>9.92</td>
      <td>18.63</td>
      <td>11.12</td>
      <td>1961-05-01</td>
      <td>5</td>
      <td>1961</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1978-08-01</th>
      <td>19.33</td>
      <td>15.09</td>
      <td>20.17</td>
      <td>8.83</td>
      <td>12.62</td>
      <td>10.41</td>
      <td>9.33</td>
      <td>12.33</td>
      <td>9.50</td>
      <td>9.92</td>
      <td>15.75</td>
      <td>18.00</td>
      <td>1978-08-01</td>
      <td>8</td>
      <td>1978</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1978-09-01</th>
      <td>8.42</td>
      <td>6.13</td>
      <td>9.87</td>
      <td>5.25</td>
      <td>3.21</td>
      <td>5.71</td>
      <td>7.25</td>
      <td>3.50</td>
      <td>7.33</td>
      <td>6.50</td>
      <td>7.62</td>
      <td>15.96</td>
      <td>1978-09-01</td>
      <td>9</td>
      <td>1978</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1978-10-01</th>
      <td>9.50</td>
      <td>6.83</td>
      <td>10.50</td>
      <td>3.88</td>
      <td>6.13</td>
      <td>4.58</td>
      <td>4.21</td>
      <td>6.50</td>
      <td>6.38</td>
      <td>6.54</td>
      <td>10.63</td>
      <td>14.09</td>
      <td>1978-10-01</td>
      <td>10</td>
      <td>1978</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1978-11-01</th>
      <td>13.59</td>
      <td>16.75</td>
      <td>11.25</td>
      <td>7.08</td>
      <td>11.04</td>
      <td>8.33</td>
      <td>8.17</td>
      <td>11.29</td>
      <td>10.75</td>
      <td>11.25</td>
      <td>23.13</td>
      <td>25.00</td>
      <td>1978-11-01</td>
      <td>11</td>
      <td>1978</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1978-12-01</th>
      <td>21.29</td>
      <td>16.29</td>
      <td>24.04</td>
      <td>12.79</td>
      <td>18.21</td>
      <td>19.29</td>
      <td>21.54</td>
      <td>17.21</td>
      <td>16.71</td>
      <td>17.83</td>
      <td>17.75</td>
      <td>25.70</td>
      <td>1978-12-01</td>
      <td>12</td>
      <td>1978</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>216 rows × 16 columns</p>
</div>




```python
Step 14 (#Downsample the record to a weekly frequency for each location.)
```


```python
weekly_resampled_data = data.resample('W').mean()
weekly_resampled_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
      <th>month</th>
      <th>year</th>
      <th>day</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>15.040000</td>
      <td>14.960000</td>
      <td>13.170000</td>
      <td>9.290000</td>
      <td>NaN</td>
      <td>9.870000</td>
      <td>13.670000</td>
      <td>10.250000</td>
      <td>10.830000</td>
      <td>12.580000</td>
      <td>18.500000</td>
      <td>15.040000</td>
      <td>1.000000</td>
      <td>1961.0</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1961-01-08</th>
      <td>13.541429</td>
      <td>11.486667</td>
      <td>10.487143</td>
      <td>6.417143</td>
      <td>9.474286</td>
      <td>6.435714</td>
      <td>11.061429</td>
      <td>6.616667</td>
      <td>8.434286</td>
      <td>8.497143</td>
      <td>12.481429</td>
      <td>13.238571</td>
      <td>1.000000</td>
      <td>1961.0</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>1961-01-15</th>
      <td>12.468571</td>
      <td>8.967143</td>
      <td>11.958571</td>
      <td>4.630000</td>
      <td>7.351429</td>
      <td>5.072857</td>
      <td>7.535714</td>
      <td>6.820000</td>
      <td>5.712857</td>
      <td>7.571429</td>
      <td>11.125714</td>
      <td>11.024286</td>
      <td>1.000000</td>
      <td>1961.0</td>
      <td>12.000000</td>
    </tr>
    <tr>
      <th>1961-01-22</th>
      <td>13.204286</td>
      <td>9.862857</td>
      <td>12.982857</td>
      <td>6.328571</td>
      <td>8.966667</td>
      <td>7.417143</td>
      <td>9.257143</td>
      <td>7.875714</td>
      <td>7.145714</td>
      <td>8.124286</td>
      <td>9.821429</td>
      <td>11.434286</td>
      <td>1.000000</td>
      <td>1961.0</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>1961-01-29</th>
      <td>19.880000</td>
      <td>16.141429</td>
      <td>18.225714</td>
      <td>12.720000</td>
      <td>17.432857</td>
      <td>14.828571</td>
      <td>15.528571</td>
      <td>15.160000</td>
      <td>14.480000</td>
      <td>15.640000</td>
      <td>20.930000</td>
      <td>22.530000</td>
      <td>1.000000</td>
      <td>1961.0</td>
      <td>26.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1978-12-03</th>
      <td>14.934286</td>
      <td>11.232857</td>
      <td>13.941429</td>
      <td>5.565714</td>
      <td>10.215714</td>
      <td>8.618571</td>
      <td>9.642857</td>
      <td>7.685714</td>
      <td>9.011429</td>
      <td>9.547143</td>
      <td>11.835714</td>
      <td>18.728571</td>
      <td>11.428571</td>
      <td>1978.0</td>
      <td>17.142857</td>
    </tr>
    <tr>
      <th>1978-12-10</th>
      <td>20.740000</td>
      <td>19.190000</td>
      <td>17.034286</td>
      <td>9.777143</td>
      <td>15.287143</td>
      <td>12.774286</td>
      <td>14.437143</td>
      <td>12.488571</td>
      <td>13.870000</td>
      <td>14.082857</td>
      <td>18.517143</td>
      <td>23.061429</td>
      <td>12.000000</td>
      <td>1978.0</td>
      <td>7.000000</td>
    </tr>
    <tr>
      <th>1978-12-17</th>
      <td>16.758571</td>
      <td>14.692857</td>
      <td>14.987143</td>
      <td>6.917143</td>
      <td>11.397143</td>
      <td>7.272857</td>
      <td>10.208571</td>
      <td>7.967143</td>
      <td>9.168571</td>
      <td>8.565714</td>
      <td>11.102857</td>
      <td>15.562857</td>
      <td>12.000000</td>
      <td>1978.0</td>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>1978-12-24</th>
      <td>11.155714</td>
      <td>8.008571</td>
      <td>13.172857</td>
      <td>4.004286</td>
      <td>7.825714</td>
      <td>6.290000</td>
      <td>7.798571</td>
      <td>8.667143</td>
      <td>7.151429</td>
      <td>8.072857</td>
      <td>11.845714</td>
      <td>18.977143</td>
      <td>12.000000</td>
      <td>1978.0</td>
      <td>21.000000</td>
    </tr>
    <tr>
      <th>1978-12-31</th>
      <td>14.951429</td>
      <td>11.801429</td>
      <td>16.035714</td>
      <td>6.507143</td>
      <td>9.660000</td>
      <td>8.620000</td>
      <td>13.708571</td>
      <td>10.477143</td>
      <td>10.868571</td>
      <td>11.471429</td>
      <td>12.947143</td>
      <td>26.844286</td>
      <td>12.000000</td>
      <td>1978.0</td>
      <td>28.000000</td>
    </tr>
  </tbody>
</table>
<p>940 rows × 15 columns</p>
</div>




```python
Step 15 (#Calculate the min, max and mean windspeeds and standard deviations of the windspeeds across all locations for each week (assume that the first week starts on January 2 1961) for the first 52 weeks.)
```


```python
df_1961 = data[data.index < pd.to_datetime('1962-01-01')]
df_1961.resample('W').mean()
df_1961.resample('W').min()
df_1961.resample('W').max()
df_1961.resample('W').std()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RPT</th>
      <th>VAL</th>
      <th>ROS</th>
      <th>KIL</th>
      <th>SHA</th>
      <th>BIR</th>
      <th>DUB</th>
      <th>CLA</th>
      <th>MUL</th>
      <th>CLO</th>
      <th>BEL</th>
      <th>MAL</th>
      <th>month</th>
      <th>year</th>
      <th>day</th>
    </tr>
    <tr>
      <th>Yr_Mo_Dy</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1961-01-01</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1961-01-08</th>
      <td>2.631321</td>
      <td>3.949525</td>
      <td>1.604761</td>
      <td>1.810743</td>
      <td>3.251660</td>
      <td>2.059546</td>
      <td>1.872222</td>
      <td>3.098404</td>
      <td>1.722255</td>
      <td>1.704941</td>
      <td>4.349139</td>
      <td>1.773062</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-01-15</th>
      <td>3.555392</td>
      <td>3.148945</td>
      <td>5.034959</td>
      <td>3.549559</td>
      <td>3.471726</td>
      <td>3.251039</td>
      <td>4.709309</td>
      <td>3.936894</td>
      <td>3.500975</td>
      <td>4.084293</td>
      <td>5.552215</td>
      <td>4.692355</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-01-22</th>
      <td>5.337402</td>
      <td>3.837785</td>
      <td>5.086229</td>
      <td>6.245541</td>
      <td>3.612875</td>
      <td>3.453432</td>
      <td>5.166300</td>
      <td>3.164990</td>
      <td>4.169112</td>
      <td>4.783952</td>
      <td>3.626584</td>
      <td>4.237239</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-01-29</th>
      <td>4.619061</td>
      <td>5.170224</td>
      <td>4.665843</td>
      <td>4.301325</td>
      <td>4.858116</td>
      <td>3.749415</td>
      <td>4.508449</td>
      <td>4.436222</td>
      <td>4.902057</td>
      <td>3.713368</td>
      <td>5.210726</td>
      <td>3.874721</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-02-05</th>
      <td>5.251408</td>
      <td>5.187395</td>
      <td>3.975166</td>
      <td>2.709106</td>
      <td>2.334619</td>
      <td>2.397066</td>
      <td>2.423454</td>
      <td>4.081158</td>
      <td>2.802490</td>
      <td>2.839501</td>
      <td>4.210858</td>
      <td>4.336104</td>
      <td>0.487950</td>
      <td>0.0</td>
      <td>13.483676</td>
    </tr>
    <tr>
      <th>1961-02-12</th>
      <td>3.587677</td>
      <td>3.608373</td>
      <td>3.290303</td>
      <td>2.262056</td>
      <td>5.571108</td>
      <td>3.048976</td>
      <td>2.974059</td>
      <td>3.022753</td>
      <td>2.914760</td>
      <td>1.746749</td>
      <td>4.063753</td>
      <td>1.828705</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-02-19</th>
      <td>5.064609</td>
      <td>3.575012</td>
      <td>4.196621</td>
      <td>4.311569</td>
      <td>2.321716</td>
      <td>3.024078</td>
      <td>4.958631</td>
      <td>2.283444</td>
      <td>2.560591</td>
      <td>2.531361</td>
      <td>5.910938</td>
      <td>4.685377</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-02-26</th>
      <td>7.020716</td>
      <td>5.147348</td>
      <td>5.578470</td>
      <td>4.482075</td>
      <td>6.480712</td>
      <td>5.029874</td>
      <td>6.037916</td>
      <td>4.869668</td>
      <td>4.705163</td>
      <td>4.920064</td>
      <td>5.091162</td>
      <td>6.182283</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-03-05</th>
      <td>0.997721</td>
      <td>2.851955</td>
      <td>1.796871</td>
      <td>1.652572</td>
      <td>2.957129</td>
      <td>2.022247</td>
      <td>3.338177</td>
      <td>2.877395</td>
      <td>2.610124</td>
      <td>1.593685</td>
      <td>4.332331</td>
      <td>3.021387</td>
      <td>0.487950</td>
      <td>0.0</td>
      <td>12.027746</td>
    </tr>
    <tr>
      <th>1961-03-12</th>
      <td>3.732263</td>
      <td>3.230167</td>
      <td>3.592909</td>
      <td>2.609928</td>
      <td>3.110857</td>
      <td>3.440419</td>
      <td>5.537269</td>
      <td>3.760557</td>
      <td>3.657690</td>
      <td>3.655113</td>
      <td>4.358759</td>
      <td>5.769890</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-03-19</th>
      <td>3.860036</td>
      <td>2.352867</td>
      <td>2.939244</td>
      <td>2.416746</td>
      <td>2.654289</td>
      <td>2.045448</td>
      <td>4.046593</td>
      <td>3.373421</td>
      <td>3.301880</td>
      <td>3.099472</td>
      <td>3.779727</td>
      <td>4.331958</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-03-26</th>
      <td>3.613298</td>
      <td>3.657265</td>
      <td>4.041121</td>
      <td>2.410127</td>
      <td>2.927188</td>
      <td>2.285729</td>
      <td>2.892270</td>
      <td>2.789682</td>
      <td>2.469432</td>
      <td>2.538224</td>
      <td>4.318069</td>
      <td>3.701846</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-04-02</th>
      <td>5.046922</td>
      <td>4.687315</td>
      <td>3.678996</td>
      <td>3.625488</td>
      <td>5.657679</td>
      <td>4.054639</td>
      <td>4.047068</td>
      <td>4.689504</td>
      <td>4.025317</td>
      <td>3.191115</td>
      <td>4.179854</td>
      <td>3.924555</td>
      <td>0.487950</td>
      <td>0.0</td>
      <td>13.483676</td>
    </tr>
    <tr>
      <th>1961-04-09</th>
      <td>4.604392</td>
      <td>2.845399</td>
      <td>2.902991</td>
      <td>2.854052</td>
      <td>2.743895</td>
      <td>2.525046</td>
      <td>2.109769</td>
      <td>1.996609</td>
      <td>1.935058</td>
      <td>2.336182</td>
      <td>3.147781</td>
      <td>2.598271</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-04-16</th>
      <td>3.937727</td>
      <td>2.607118</td>
      <td>4.585752</td>
      <td>2.664416</td>
      <td>1.941836</td>
      <td>2.388107</td>
      <td>1.970667</td>
      <td>2.379446</td>
      <td>2.123279</td>
      <td>2.161137</td>
      <td>3.641464</td>
      <td>2.747842</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-04-23</th>
      <td>5.676655</td>
      <td>4.631736</td>
      <td>5.456290</td>
      <td>3.835403</td>
      <td>4.122437</td>
      <td>3.835998</td>
      <td>3.254663</td>
      <td>3.935731</td>
      <td>3.656682</td>
      <td>3.347972</td>
      <td>4.735096</td>
      <td>5.908542</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-04-30</th>
      <td>4.349662</td>
      <td>2.871425</td>
      <td>3.732776</td>
      <td>1.897616</td>
      <td>3.259907</td>
      <td>2.528436</td>
      <td>3.565777</td>
      <td>3.426255</td>
      <td>2.718926</td>
      <td>2.840568</td>
      <td>2.948237</td>
      <td>5.108365</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-05-07</th>
      <td>5.025507</td>
      <td>3.750835</td>
      <td>4.301778</td>
      <td>3.141495</td>
      <td>5.781916</td>
      <td>3.324038</td>
      <td>4.419008</td>
      <td>4.461950</td>
      <td>3.558856</td>
      <td>3.620819</td>
      <td>8.003490</td>
      <td>7.728504</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-05-14</th>
      <td>3.371022</td>
      <td>3.782947</td>
      <td>3.002225</td>
      <td>3.509695</td>
      <td>4.813159</td>
      <td>4.660173</td>
      <td>5.744586</td>
      <td>4.690361</td>
      <td>5.126826</td>
      <td>5.460237</td>
      <td>3.968272</td>
      <td>7.858246</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-05-21</th>
      <td>3.631730</td>
      <td>2.468906</td>
      <td>3.767505</td>
      <td>0.668791</td>
      <td>2.541271</td>
      <td>1.377071</td>
      <td>1.650089</td>
      <td>2.221636</td>
      <td>1.613885</td>
      <td>2.216889</td>
      <td>1.975853</td>
      <td>3.310819</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-05-28</th>
      <td>2.739433</td>
      <td>3.378537</td>
      <td>6.355768</td>
      <td>1.378803</td>
      <td>2.945134</td>
      <td>1.873381</td>
      <td>2.350104</td>
      <td>3.207147</td>
      <td>1.990891</td>
      <td>2.575661</td>
      <td>3.024524</td>
      <td>3.811818</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-06-04</th>
      <td>3.099701</td>
      <td>1.868125</td>
      <td>3.474607</td>
      <td>2.323826</td>
      <td>2.305695</td>
      <td>1.332009</td>
      <td>2.300028</td>
      <td>0.915184</td>
      <td>1.954609</td>
      <td>2.096989</td>
      <td>2.611139</td>
      <td>2.593586</td>
      <td>0.534522</td>
      <td>0.0</td>
      <td>14.738999</td>
    </tr>
    <tr>
      <th>1961-06-11</th>
      <td>2.248597</td>
      <td>1.524836</td>
      <td>1.887475</td>
      <td>1.603775</td>
      <td>2.238228</td>
      <td>2.204087</td>
      <td>2.514689</td>
      <td>2.857527</td>
      <td>1.695090</td>
      <td>2.158323</td>
      <td>3.993062</td>
      <td>4.925055</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-06-18</th>
      <td>3.009482</td>
      <td>3.509444</td>
      <td>3.429057</td>
      <td>2.130352</td>
      <td>4.175947</td>
      <td>3.292713</td>
      <td>3.417989</td>
      <td>4.858023</td>
      <td>2.900464</td>
      <td>3.792400</td>
      <td>6.477887</td>
      <td>6.242673</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-06-25</th>
      <td>1.982035</td>
      <td>2.212460</td>
      <td>1.916454</td>
      <td>1.332234</td>
      <td>1.422401</td>
      <td>1.448318</td>
      <td>2.455385</td>
      <td>2.109358</td>
      <td>2.042257</td>
      <td>2.286218</td>
      <td>2.498386</td>
      <td>3.063011</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-07-02</th>
      <td>2.557856</td>
      <td>2.902411</td>
      <td>1.161629</td>
      <td>1.911018</td>
      <td>2.172125</td>
      <td>1.626363</td>
      <td>1.927673</td>
      <td>3.065467</td>
      <td>1.745125</td>
      <td>1.564144</td>
      <td>6.303747</td>
      <td>3.652313</td>
      <td>0.487950</td>
      <td>0.0</td>
      <td>12.998168</td>
    </tr>
    <tr>
      <th>1961-07-09</th>
      <td>3.664855</td>
      <td>2.686658</td>
      <td>2.995919</td>
      <td>2.898890</td>
      <td>3.661383</td>
      <td>2.459639</td>
      <td>3.493425</td>
      <td>3.160424</td>
      <td>3.453210</td>
      <td>3.657179</td>
      <td>4.537988</td>
      <td>3.665705</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-07-16</th>
      <td>5.168710</td>
      <td>3.849630</td>
      <td>2.166206</td>
      <td>2.665625</td>
      <td>4.596567</td>
      <td>3.164715</td>
      <td>4.489523</td>
      <td>4.083629</td>
      <td>3.978635</td>
      <td>3.271899</td>
      <td>4.971060</td>
      <td>4.974273</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-07-23</th>
      <td>1.047978</td>
      <td>1.400010</td>
      <td>2.783208</td>
      <td>1.158908</td>
      <td>0.764956</td>
      <td>0.617815</td>
      <td>1.757905</td>
      <td>1.479152</td>
      <td>0.873207</td>
      <td>1.439785</td>
      <td>2.050218</td>
      <td>2.133994</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-07-30</th>
      <td>4.157641</td>
      <td>3.203206</td>
      <td>3.276465</td>
      <td>2.843207</td>
      <td>4.514505</td>
      <td>3.786633</td>
      <td>5.110195</td>
      <td>4.060478</td>
      <td>4.504844</td>
      <td>4.350268</td>
      <td>5.580903</td>
      <td>6.664574</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-08-06</th>
      <td>2.950887</td>
      <td>3.985226</td>
      <td>3.483894</td>
      <td>1.647275</td>
      <td>4.189524</td>
      <td>2.642246</td>
      <td>3.709319</td>
      <td>3.921508</td>
      <td>3.217501</td>
      <td>2.903018</td>
      <td>4.901377</td>
      <td>4.448251</td>
      <td>0.377964</td>
      <td>0.0</td>
      <td>10.533394</td>
    </tr>
    <tr>
      <th>1961-08-13</th>
      <td>4.422268</td>
      <td>2.053326</td>
      <td>2.174407</td>
      <td>1.921080</td>
      <td>3.071872</td>
      <td>2.045195</td>
      <td>3.073187</td>
      <td>2.088368</td>
      <td>2.718228</td>
      <td>2.073777</td>
      <td>2.931302</td>
      <td>3.356585</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-08-20</th>
      <td>2.283635</td>
      <td>2.523416</td>
      <td>1.766039</td>
      <td>1.938109</td>
      <td>2.568539</td>
      <td>2.227127</td>
      <td>3.197566</td>
      <td>2.972809</td>
      <td>2.339544</td>
      <td>2.730237</td>
      <td>4.086725</td>
      <td>3.934238</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-08-27</th>
      <td>3.395857</td>
      <td>3.174702</td>
      <td>3.071403</td>
      <td>2.455711</td>
      <td>4.380624</td>
      <td>3.416186</td>
      <td>4.170083</td>
      <td>4.900671</td>
      <td>4.120185</td>
      <td>3.855302</td>
      <td>6.711322</td>
      <td>4.947608</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-09-03</th>
      <td>4.398615</td>
      <td>7.474025</td>
      <td>4.395383</td>
      <td>3.790030</td>
      <td>6.128522</td>
      <td>4.455552</td>
      <td>3.920110</td>
      <td>5.012759</td>
      <td>4.155931</td>
      <td>3.993736</td>
      <td>7.678051</td>
      <td>6.308087</td>
      <td>0.534522</td>
      <td>0.0</td>
      <td>14.738999</td>
    </tr>
    <tr>
      <th>1961-09-10</th>
      <td>5.207278</td>
      <td>4.003996</td>
      <td>3.922643</td>
      <td>3.151502</td>
      <td>3.178791</td>
      <td>2.965546</td>
      <td>4.258696</td>
      <td>3.074692</td>
      <td>3.767708</td>
      <td>3.649278</td>
      <td>4.220584</td>
      <td>6.049619</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-09-17</th>
      <td>7.679190</td>
      <td>5.360585</td>
      <td>6.638947</td>
      <td>5.560509</td>
      <td>6.279010</td>
      <td>4.706530</td>
      <td>4.235755</td>
      <td>4.565163</td>
      <td>4.847073</td>
      <td>5.128338</td>
      <td>4.464252</td>
      <td>6.332885</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-09-24</th>
      <td>1.267399</td>
      <td>3.445262</td>
      <td>2.322229</td>
      <td>1.609614</td>
      <td>3.125219</td>
      <td>2.293031</td>
      <td>1.444916</td>
      <td>3.342247</td>
      <td>1.523142</td>
      <td>2.354092</td>
      <td>5.235868</td>
      <td>3.113507</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-10-01</th>
      <td>4.559572</td>
      <td>2.812482</td>
      <td>4.201062</td>
      <td>2.050553</td>
      <td>3.353967</td>
      <td>1.901786</td>
      <td>2.098203</td>
      <td>3.425963</td>
      <td>1.790306</td>
      <td>3.908397</td>
      <td>5.091268</td>
      <td>4.696504</td>
      <td>0.377964</td>
      <td>0.0</td>
      <td>10.160615</td>
    </tr>
    <tr>
      <th>1961-10-08</th>
      <td>5.596710</td>
      <td>5.060803</td>
      <td>4.394234</td>
      <td>3.249050</td>
      <td>3.830935</td>
      <td>3.686641</td>
      <td>3.420894</td>
      <td>3.313201</td>
      <td>3.717239</td>
      <td>4.296870</td>
      <td>4.800403</td>
      <td>5.462002</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-10-15</th>
      <td>4.780675</td>
      <td>2.707483</td>
      <td>5.979099</td>
      <td>2.367850</td>
      <td>2.246657</td>
      <td>1.969085</td>
      <td>3.409743</td>
      <td>2.506401</td>
      <td>2.947025</td>
      <td>3.569308</td>
      <td>4.113200</td>
      <td>4.098130</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-10-22</th>
      <td>7.888314</td>
      <td>5.998199</td>
      <td>5.463782</td>
      <td>4.989763</td>
      <td>6.095112</td>
      <td>3.801637</td>
      <td>5.334910</td>
      <td>5.199929</td>
      <td>3.785875</td>
      <td>5.890511</td>
      <td>5.645871</td>
      <td>7.468377</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-10-29</th>
      <td>7.957637</td>
      <td>6.879973</td>
      <td>7.428776</td>
      <td>5.576503</td>
      <td>7.344744</td>
      <td>5.101188</td>
      <td>4.542684</td>
      <td>5.506544</td>
      <td>4.448500</td>
      <td>6.277629</td>
      <td>7.056150</td>
      <td>8.340881</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-11-05</th>
      <td>3.369201</td>
      <td>3.900278</td>
      <td>2.461109</td>
      <td>2.448363</td>
      <td>3.664806</td>
      <td>2.513051</td>
      <td>2.727816</td>
      <td>3.599111</td>
      <td>3.003274</td>
      <td>2.784450</td>
      <td>4.038493</td>
      <td>3.870800</td>
      <td>0.487950</td>
      <td>0.0</td>
      <td>13.483676</td>
    </tr>
    <tr>
      <th>1961-11-12</th>
      <td>3.939811</td>
      <td>2.141191</td>
      <td>6.779554</td>
      <td>2.930324</td>
      <td>2.090641</td>
      <td>1.414308</td>
      <td>2.388943</td>
      <td>2.181840</td>
      <td>2.153102</td>
      <td>2.843518</td>
      <td>2.532196</td>
      <td>3.690752</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-11-19</th>
      <td>2.784358</td>
      <td>3.208548</td>
      <td>9.415716</td>
      <td>4.176374</td>
      <td>2.092809</td>
      <td>3.440953</td>
      <td>7.027159</td>
      <td>3.452202</td>
      <td>3.488521</td>
      <td>4.402588</td>
      <td>3.643285</td>
      <td>3.787654</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-11-26</th>
      <td>3.214368</td>
      <td>3.277904</td>
      <td>3.622254</td>
      <td>1.824938</td>
      <td>2.132751</td>
      <td>1.822767</td>
      <td>3.551685</td>
      <td>2.276663</td>
      <td>2.392934</td>
      <td>2.747452</td>
      <td>5.407223</td>
      <td>6.475867</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-12-03</th>
      <td>5.704669</td>
      <td>5.107089</td>
      <td>4.163650</td>
      <td>4.097123</td>
      <td>5.536334</td>
      <td>3.534980</td>
      <td>4.186505</td>
      <td>3.744471</td>
      <td>3.658796</td>
      <td>3.680477</td>
      <td>5.552648</td>
      <td>5.233192</td>
      <td>0.534522</td>
      <td>0.0</td>
      <td>14.205968</td>
    </tr>
    <tr>
      <th>1961-12-10</th>
      <td>4.890152</td>
      <td>4.115506</td>
      <td>4.682044</td>
      <td>3.782631</td>
      <td>3.345941</td>
      <td>3.481252</td>
      <td>4.357862</td>
      <td>4.503161</td>
      <td>3.452864</td>
      <td>4.156207</td>
      <td>4.667933</td>
      <td>7.345893</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-12-17</th>
      <td>4.095106</td>
      <td>3.587886</td>
      <td>3.843380</td>
      <td>3.501489</td>
      <td>3.943048</td>
      <td>3.312448</td>
      <td>6.474478</td>
      <td>3.482027</td>
      <td>4.333020</td>
      <td>4.633398</td>
      <td>6.531043</td>
      <td>5.665006</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-12-24</th>
      <td>4.959717</td>
      <td>2.220866</td>
      <td>5.653229</td>
      <td>5.341288</td>
      <td>4.898600</td>
      <td>4.019469</td>
      <td>5.724775</td>
      <td>4.134367</td>
      <td>4.243508</td>
      <td>4.637096</td>
      <td>5.065308</td>
      <td>5.048035</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
    <tr>
      <th>1961-12-31</th>
      <td>5.787783</td>
      <td>4.566479</td>
      <td>9.739918</td>
      <td>4.167851</td>
      <td>3.018856</td>
      <td>2.674370</td>
      <td>5.142213</td>
      <td>4.289240</td>
      <td>3.325214</td>
      <td>3.526625</td>
      <td>3.262217</td>
      <td>3.012729</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>2.160247</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
QUESTION 5
```


```python
SOLUTION
```


```python
Step 1 (#Import the necessary libraries)
```


```python
import pandas as pd
```


```python
Step 2 (#Import the dataset from this address.)
```


```python
url = 'https://raw.githubusercontent.com/justmarkham/DAT8/master/data/chipotle.tsv'
```


```python
Step 3 (#Assign it to a variable called chipo.)
```


```python
chipo = pd.read_csv('https://raw.githubusercontent.com/justmarkham/DAT8/master/data/chipotle.tsv', sep='\t')
```


```python
chipo.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>quantity</th>
      <th>item_name</th>
      <th>choice_description</th>
      <th>item_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>Chips and Fresh Tomato Salsa</td>
      <td>NaN</td>
      <td>$2.39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Izze</td>
      <td>[Clementine]</td>
      <td>$3.39</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>Nantucket Nectar</td>
      <td>[Apple]</td>
      <td>$3.39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Chips and Tomatillo-Green Chili Salsa</td>
      <td>NaN</td>
      <td>$2.39</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>2</td>
      <td>Chicken Bowl</td>
      <td>[Tomatillo-Red Chili Salsa (Hot), [Black Beans...</td>
      <td>$16.98</td>
    </tr>
  </tbody>
</table>
</div>




```python
Step 4 (#See the first 10 entries)
```


```python
print(chipo.head(10))
```

       order_id  quantity                              item_name  \
    0         1         1           Chips and Fresh Tomato Salsa   
    1         1         1                                   Izze   
    2         1         1                       Nantucket Nectar   
    3         1         1  Chips and Tomatillo-Green Chili Salsa   
    4         2         2                           Chicken Bowl   
    5         3         1                           Chicken Bowl   
    6         3         1                          Side of Chips   
    7         4         1                          Steak Burrito   
    8         4         1                       Steak Soft Tacos   
    9         5         1                          Steak Burrito   
    
                                      choice_description item_price  
    0                                                NaN     $2.39   
    1                                       [Clementine]     $3.39   
    2                                            [Apple]     $3.39   
    3                                                NaN     $2.39   
    4  [Tomatillo-Red Chili Salsa (Hot), [Black Beans...    $16.98   
    5  [Fresh Tomato Salsa (Mild), [Rice, Cheese, Sou...    $10.98   
    6                                                NaN     $1.69   
    7  [Tomatillo Red Chili Salsa, [Fajita Vegetables...    $11.75   
    8  [Tomatillo Green Chili Salsa, [Pinto Beans, Ch...     $9.25   
    9  [Fresh Tomato Salsa, [Rice, Black Beans, Pinto...     $9.25   
    


```python
Step 5 (#What is the number of observations in the dataset?)
```


```python
print(chipo.shape[0])
```

    4622
    


```python
Step 6 (#What is the number of columns in the dataset?)
```


```python
print(chipo.shape[1])
```

    5
    


```python
Step 7 (#Print the name of all the columns.)
```


```python
print(chipo.columns)
```

    Index(['order_id', 'quantity', 'item_name', 'choice_description',
           'item_price'],
          dtype='object')
    


```python
Step 8 (#How is the dataset indexed?)
```


```python
print(chipo.index)
```

    RangeIndex(start=0, stop=4622, step=1)
    


```python
Step 9 (#Which was the most-ordered item?)
```


```python
print(chipo[chipo.quantity==chipo.quantity.max()].item_name)
```

    3598    Chips and Fresh Tomato Salsa
    Name: item_name, dtype: object
    


```python
Step 10 (#For the most-ordered item, how many items were ordered?)
```


```python
print(chipo[chipo.quantity==chipo.quantity.max()].quantity)
```

    3598    15
    Name: quantity, dtype: int64
    


```python
Step 11 (#What was the most ordered item in the choice_description column?)
```


```python
print(chipo.groupby('choice_description').agg({'quantity':'sum'}).sort_values(by='quantity', ascending=False).head(1).index[0])
```

    [Diet Coke]
    


```python
Step 12 (#How many items were orderd in total?)
```


```python
print(chipo.quantity.sum())
```

    4972
    


```python
Step 13 (#Turn the item price into a float
#Check the item price type
#Create a lambda function and change the type of item price
#Check the item price type)
```


```python
"""chipo['item_price'] = chipo['item_price'].str.replace('$', '').astype(float)"""
```


```python
print(chipo['item_price'].dtype)
```

    object
    


```python
Step 14 (#How much was the revenue for the period in the dataset?)
```


```python
dollarizer = lambda x: float(x[1:-1])
chipo.item_price = chipo.item_price.apply(dollarizer)
```


```python
revenue = (chipo['quantity'] * chipo['item_price']).sum()
revenue
```




    39237.02




```python
Step 15 (#How many orders were made in the period?)
```


```python
print(len(chipo.groupby('order_id').agg({'order_id':'count'})))
```

    1834
    


```python
Step 16 (#What is the average revenue amount per order?)
```


```python
print(chipo.groupby('order_id').agg({'item_price':'mean'}).mean())
```

    item_price    7.841911
    dtype: float64
    


```python
Step 17 (#How many different items are sold?)
```


```python
print(len(chipo.groupby('item_name').agg({'item_name':'count'})))
```

    50
    


```python

```


```python
QUESTION 6 (#Create a line plot showing the number of marriages and divorces per capita in the U.S. between 1867 and 2014. Label both lines and show the legend.

Don't forget to label your axes!)
```


```python
SOLUTION
```


```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv('https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/4479949?X-Blackboard-Expiration=1650099600000&X-Blackboard-Signature=XXvVqe7bsGGodQONGdnCCFQXyLY4j%2FALenf0rlSUeKc%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27us-marriages-divorces-1867-2014.csv&response-content-type=text%2Fcsv&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIQC7HYJAq4cCX1t477xaYvUIL1p6c3ic%2BI9Ka39z%2BkfVyQIgCtnPj1OlpUU33NtdQNs%2BLzwh17qsaPrhidTNZgEt8OEqgwQInP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw1NTY5MDM4NjEzNjEiDEPUoDpQhx%2F4T7pAoSrXA%2B9q%2B6L3qbGiwuqyDRB4Aa5vj9f7eYB1X7eRyjMVhKXQgo78nMzqfRDnk3Sp0a7mqaN2kcdZaxitvezu2tljOcmH48IUWdBjBmmtcrhu1nbHoJNUWBjJV36jRxkafvKV%2BNL%2Bued9qqyi4SO0CMG4O9EB4wm8c%2FGaDvKqwQ0cwUfLFeyyXMMMLgrbedhEQKbgUN0irT8%2BazU%2F9E70cbPjmRTnejccJ9136GLHj0M00D%2Bd8he%2BptalpyFO8pgcKFLiWuGKdG9mK0Lq%2BK7AN0mVcf%2Bbh8S%2FsgCdzhhLtykloI5KUaqnrl%2BehxlNCCWAARFo8DWd%2FnDa84nMVmdHzCQ%2FkBxdoT5v9e5SzGIn4rBtkBFejwJ%2FuaiosxZLAZb5AG6ePeuxLYubismb0IUOBNk2NF9MSVwLT6T1YCF7xUQo7dHDNq287KRycZT7PcaBjqMW3%2Bq7359Ny7YcjsE13JyMjt6nEwioaYJj3Ed74BLP%2B0PxcKB9FeB1H5Ghd2DCMaJT6zpLI%2FsYoeKDIEH%2Fj%2BIMp%2BIF%2F4i1gsVzLJAOOPfcCmENIVSN2qoxUjTQ87OG10tFB9mXfxD6jbsUkrecFeQHXROHdDvB8PSgJIDOG1AHpyEkgie7Zyb1MjDi1eiSBjqlAYzisI1lP4VhB5%2F%2BneLZptEbJA3TQhKOMWej6QgpSM3IT3gdR4HDU9b7PxiZHITKZ22VXUMtYoQIw%2FkD7rzw0xgWx77mranvof1%2FWHxwLmXAVPKmMgFJxiNVIHWbc52Sq5Yj0FxzMMRewpYIdW7Koy%2Fxap2qlF4pYjjbzmneybNnBwSiA94sL8h%2FIBB%2Br1LayoMZ7Iu%2Ft4qweC3SPy0faKOGvVtuqg%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T030000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRYY4ZTBZHQ%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=6ea4790148f646b326a590a3e91276afbf39d6534a30274741ed8ae36cd6bef9')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Marriages</th>
      <th>Divorces</th>
      <th>Population</th>
      <th>Marriages_per_1000</th>
      <th>Divorces_per_1000</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1867</td>
      <td>357000.0</td>
      <td>10000.0</td>
      <td>36970000</td>
      <td>9.7</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1868</td>
      <td>345000.0</td>
      <td>10000.0</td>
      <td>37885000</td>
      <td>9.1</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1869</td>
      <td>348000.0</td>
      <td>11000.0</td>
      <td>38870000</td>
      <td>9.0</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1870</td>
      <td>352000.0</td>
      <td>11000.0</td>
      <td>39905000</td>
      <td>8.8</td>
      <td>0.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1871</td>
      <td>359000.0</td>
      <td>12000.0</td>
      <td>41010000</td>
      <td>8.8</td>
      <td>0.3</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.plot(x='Year', y=['Marriages_per_1000', 'Divorces_per_1000'])
plt.title('Marriages and Divorces per capital in the U.S. between 1867 and 2014')
plt.ylabel('Marriages and Divorces per Capita')
plt.xlabel('Year')
plt.grid(axis='x')
plt.show()
```


    
![png](output_160_0.png)
    



```python

```


```python
QUESTION 7
```


```python
SOLUTION
```


```python
# Importing the matplotlib library
```


```python
import numpy as np
import matplotlib.pyplot as plt
```


```python
plt.figure(figsize=[15, 10])    
marriage = [709000, 1667000, 2315000]
divorce = [56000, 385000, 944000]
X = np.arange(len(marriage))
plt.bar(X, marriage, color = 'blue', width = 0.25)
plt.bar(X + 0.25, divorce, color = 'yellow', width = 0.25)
plt.legend(['Marriage', 'Divorce'])
plt.xticks([i + 0.25 for i in range(3)], ['1900', '1950', '2000'])
plt.title("Vertical Bar Chart")
plt.xlabel('Marriage-Divorce-per-Capita between 1900, 1950, and 2000')
plt.ylabel('Total')
plt.show()
```


    
![png](output_166_0.png)
    



```python

```


```python
QUESTION 8 (#Create a horizontal bar chart that compares the deadliest actors in Hollywood. Sort the actors by their kill count and label each bar with the corresponding actor's name.

Don't forget to label your axes!)
```


```python
SOLUTION
```


```python
#import the neccessary library
```


```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv('https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/10029930?X-Blackboard-Expiration=1650099600000&X-Blackboard-Signature=RNgPpA4nvjTXVDJnpl5EmZrDwikbe%2FTRk9CMrI04ITM%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27actor_kill_counts.csv&response-content-type=text%2Fcsv&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPT%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIDfwVB4HTtHhl%2BNMtub8SNNouEb15EfHJz5PqOsh%2FyI8AiEAuL4%2B2HpTshGN05dhcZucYPy%2FmU9Lgs90GIv80VL9S6sqgwQInP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARAAGgw1NTY5MDM4NjEzNjEiDIK3FdEoSuEbrxmk2irXA9FYyJO062DioWTMaPr5ZRVsxrzoiBEUIAvKk9m5TxsC8vGVZZf9QgQeva5SwD7S%2B3sgDU9kjAgbS3t7h8RRWpGGEJUWbXGD6SjnRLle0hPRpzY8edLh%2Bm6B2Ynd1y5dvbXxdJiqfYpYDKTfN6X3EKMbdPQDRsH40tB8%2B4HfkGUSSrhktMCJAMq8HUnx77M0Tj0FgKD4IUnLg72pYOY2mDrUmelh9mdlKhx8acIJe0KDoNMBGRKPZo1UNoyENcow13ghtAdojyXGJZs5zh8fKPZQsrABLDl810Xs%2BDLok2NPsMEOVgeJohMJhX0ZHmZ55DH63HL2U5FcOITuSNFhuKVRVqju9JhOKCLhs8zclCe2KexU5P0hMIYpUMMFNHruOpH6aQ%2BZGK5OmIqrc3DVOWI75TnZzv3rb9E9qpL%2FZxFboK7rxLjOqZ8UcnYhOcDvpvETKQM0Ja%2BLgZpXXFOUgnLgOHJFvaPApLljS3O4%2FcUXmNMzLFZfBlEEvEF3NPjPrH9CuQhL8SVgWEt7pqmRIX0eCrwbyLBlwtDLxU5bXyMpoaaWkrTY4XMpeUEIf3HWaZVbQMQdbWbgjggtDLWOH0fgxPEg%2BmZZo8iGDWw%2BANBTpvsx5aF%2F3TDK6eiSBjqlAUBFTv98MRgmF1ypvuAHqmkQAPFKoldYIYxtuoefeHzym8p5XU90brKlI0kFx%2B6XnbER3ch3K7ZwvfjSIsJahobDNf8eXX1vo6sPtXsUAwWHS0NFijDiEU%2BnRjfiiGW4EIaxtba2zDWwrRa0GzKkia1IYFEufNSpiG864LA%2FQSik0%2FP8nE6P94t3yHRbCc%2FH5bduj4a13B2E5kkSZL%2FPu2xxUcf6mg%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T030000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRY3SD63MKY%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=0e286031350adee6ebdd30cbda6c465a09d6602a4f40470ceee1b128e5690297')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actor</th>
      <th>Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Arnold Schwarzenegger</td>
      <td>369</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Chow Yun-Fat</td>
      <td>295</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Clint Eastwood</td>
      <td>207</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Clive Owen</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Dolph Lundgren</td>
      <td>239</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.plot.barh(x='Actor', y='Count')
plt.ylabel('Actor')
plt.xlabel('Kill Count')
plt.grid(axis='x', linestyle = '--')
plt.show()
```


    
![png](output_174_0.png)
    



```python

```


```python
QUESTION 9 (#Create a pie chart showing the fraction of all Roman Emperors that were assassinated.

Make sure that the pie chart is an even circle, labels the categories, and shows the percentage breakdown of the categories.)
```


```python
SOLUTION
```


```python
#import the necessary library
```


```python
import matplotlib.pyplot as plt
import pandas as pd
```


```python
roman_emperors = pd.read_csv('https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/10029932?X-Blackboard-Expiration=1650099600000&X-Blackboard-Signature=Yn0ZHx3uVQLJL83etb0f6uu4n8eAkW%2B5CXlAjbTDupQ%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27roman-emperor-reigns.csv&response-content-type=text%2Fcsv&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPX%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJIMEYCIQDu9R92BI4bcjeEA1p1qoBqn1KY3pubU5OtsALaca4X4QIhAKbPWFZuFxaKnWzKEYDgYrH1USxyGR7C8RLtAIWk6kH5KoMECJ7%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMNTU2OTAzODYxMzYxIgydaaAFXpzoLTRnHacq1wPJhXiADl7g0%2BoqQQxNswFRkOXqsuvLr4tK0jE%2FlpqIrkO3pSNd%2BSERiMSrbkm889DJaTSvxYP%2BHFQ5%2FRVNDtOaDyvViXJ5kyV0jiUSSZ83S2t%2FjkQiU47DaE0jtrvmEglasb8Y19rZB48YWazrqDmFtZBMOvj1pNebfZhtfzWoVnP34MQ0XM3mDE6VtxAaOxuRkwPyWDY184u9216%2FepNGIxnzRN%2FD%2B3ebjhQK1EJEPXi3HDtlhLhyT6MMeDVKB2pg1w278BMY4OgzA3qoN0giJ%2BUxye43fVHbeSeZ3E5snsX4tAStLW45CSAl1%2BXSMJleL47Cs9yZlqPOkmFXCaoArgAfrxwieyAxPzy7Uy1ZoS8oTyCbdjkL0h1W3Juj79yfxwIkOxz%2F4w%2FrNJ51aTrT%2Fw3JGmIknzE1o9k%2Bc4vRiPuCQaRzqSztRAxi5kWZZSoJSGMYw6ynq43L9rQ7iYWsgcFYUIhIiGRo3ZtxSFF5yeeluEnO%2FyZn958TGCCPTMCRD9PBOqY3OtQGe3%2FWUdWVeBpg1UXNF%2FcmctCPz5SXWsYJlZLd7TLdHO3nRY0ELaEchWgvN4O8Ul36JCSb94iXQvklyLkCqFNKY0CByouh30htgN6AcigwxpfpkgY6pAEUn80ZoXFqsChUR%2FYz3UTQKti7HcGBhT2mjclFK0Ybw02oUYmrLeM%2FjEtyBALS5iMtU6yHV%2BdGeTjVjnJflbsHvIN0EaXFLV71rXAbtRU%2B%2F%2BUDLyyUHii6GPYIb8hEafd38CuGS%2FCY1N6BX3zUtAFJz2UOhBt5MAlKsMgteA7wQhIpbwdYq1XILnlz6UCM2ysd8jMY7NOztmPypQXW8Lw7TURWdQ%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T030000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRY32ITDAOL%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=aeaa31ae8358bee791e0f208a082c396604975f6c3746de6ef45f0e35cc8419c')
assassinated_emperors = roman_emperors[
roman_emperors['Cause_of_Death'].apply(lambda x: 'assassinated' in x.lower())]
print(assassinated_emperors)
number_assassinated = len(assassinated_emperors)
print(number_assassinated)
other_deaths = len(roman_emperors) - number_assassinated
print(other_deaths)
emperor = assassinated_emperors["Emperor"]
cause_of_death = assassinated_emperors["Cause_of_Death"]
plt.pie(range(len(cause_of_death)), labels=emperor,autopct='%1.1f%%', startangle=90, radius=0.04 * 100)
```

                   Emperor  Length_of_Reign         Cause_of_Death
    0             Augustus            40.58  Possibly assassinated
    1             Tiberius            22.50  Possibly assassinated
    2             Caligula             4.83           Assassinated
    3             Claudius            13.75  Possibly assassinated
    5                Galba             0.58           Assassinated
    7            Vitellius             0.67           Assassinated
    10            Domitian            15.00           Assassinated
    17            Commodus            15.00           Assassinated
    18            Pertinax             0.25           Assassinated
    21           Caracalla            19.00           Assassinated
    22                Geta             3.00           Assassinated
    24          Elagabalus             3.75           Assassinated
    25   Severus Alexander            13.00           Assassinated
    26         Maximinus I             3.25           Assassinated
    29            Pupienus             0.25           Assassinated
    30            Balbinus             0.25           Assassinated
    31         Gordian III             6.00  Possibly assassinated
    35  Trebonianus Gallus             2.00           Assassinated
    36            Aemilian             0.16           Assassinated
    38           Gallienus            15.00           Assassinated
    40          Quintillus             0.83  Possibly assassinated
    41            Aurelian             5.00           Assassinated
    42             Tacitus             0.75  Possibly assassinated
    43             Florian             0.25           Assassinated
    44              Probus             6.00           Assassinated
    46            Numerian             1.00  Possibly assassinated
    52          Severus II             1.00           Assassinated
    59          Constans I            13.00           Assassinated
    65             Gratian            16.00           Assassinated
    66      Valentinian II            17.00  Possibly assassinated
    30
    38
    




    ([<matplotlib.patches.Wedge at 0x281dcd99b80>,
      <matplotlib.patches.Wedge at 0x281dcda6340>,
      <matplotlib.patches.Wedge at 0x281dcda6a60>,
      <matplotlib.patches.Wedge at 0x281dcdb21c0>,
      <matplotlib.patches.Wedge at 0x281dcdb28e0>,
      <matplotlib.patches.Wedge at 0x281dcdb2fd0>,
      <matplotlib.patches.Wedge at 0x281dcdbe760>,
      <matplotlib.patches.Wedge at 0x281dcdbee80>,
      <matplotlib.patches.Wedge at 0x281dcdc95e0>,
      <matplotlib.patches.Wedge at 0x281dcdc9d00>,
      <matplotlib.patches.Wedge at 0x281dc96c760>,
      <matplotlib.patches.Wedge at 0x281dcdd8b50>,
      <matplotlib.patches.Wedge at 0x281dcde52b0>,
      <matplotlib.patches.Wedge at 0x281dcde59d0>,
      <matplotlib.patches.Wedge at 0x281dcdef130>,
      <matplotlib.patches.Wedge at 0x281dcdef850>,
      <matplotlib.patches.Wedge at 0x281dcdeff70>,
      <matplotlib.patches.Wedge at 0x281dcdfd6d0>,
      <matplotlib.patches.Wedge at 0x281dcdfddf0>,
      <matplotlib.patches.Wedge at 0x281dce0a550>,
      <matplotlib.patches.Wedge at 0x281dce0ac70>,
      <matplotlib.patches.Wedge at 0x281dce173d0>,
      <matplotlib.patches.Wedge at 0x281dce17af0>,
      <matplotlib.patches.Wedge at 0x281dce25250>,
      <matplotlib.patches.Wedge at 0x281dce25970>,
      <matplotlib.patches.Wedge at 0x281dce330d0>,
      <matplotlib.patches.Wedge at 0x281dce337f0>,
      <matplotlib.patches.Wedge at 0x281dce33f10>,
      <matplotlib.patches.Wedge at 0x281dce3f670>,
      <matplotlib.patches.Wedge at 0x281dce3fd90>],
     [Text(2.6942229581241775e-16, 4.4, 'Augustus'),
      Text(-0.03177675278419733, 4.399885252819952, 'Tiberius'),
      Text(-0.12709043759740613, 4.398164164815964, 'Caligula'),
      Text(-0.28579192629584915, 4.390708709862693, 'Claudius'),
      Text(-0.507301749046913, 4.370657265837021, 'Galba'),
      Text(-0.7901165380116754, 4.328477313832249, 'Vitellius'),
      Text(-1.1311283790398228, 4.252122833377553, 'Domitian'),
      Text(-1.5247781988342142, 4.127354048825941, 'Commodus'),
      Text(-1.962085350560337, 3.938301801172242, 'Pertinax'),
      Text(-2.4296267179942834, 3.668366668042922, 'Caracalla'),
      Text(-2.908580193791541, 3.3015392253134848, 'Geta'),
      Text(-3.373997411424452, 2.8242063429751556, 'Elagabalus'),
      Text(-3.794524017596911, 2.2274621163737445, 'Severus Alexander'),
      Text(-4.132833132477549, 1.5098643313542484, 'Maximinus I'),
      Text(-4.347064366561511, 0.6804641011627081, 'Pupienus'),
      Text(-4.3935470223869455, -0.23821117117970206, 'Balbinus'),
      Text(-4.231008228849504, -1.2077124522864648, 'Gordian III'),
      Text(-3.82630079602044, -2.172423121395404, 'Trebonianus Gallus'),
      Text(-3.161413826326028, -3.0603043343292877, 'Aemilian'),
      Text(-2.2411497112429983, -3.786455858952462, 'Gallienus'),
      Text(-1.1003901448354518, -4.260180926809214, 'Quintillus'),
      Text(0.1906024608964493, -4.395869732134953, 'Aurelian'),
      Text(1.5247781505303664, -4.1273540666709465, 'Tacitus'),
      Text(2.7628313144554104, -3.424436176637636, 'Florian'),
      Text(3.7453766419133196, -2.3091456883899952, 'Probus'),
      Text(4.313506920674576, -0.8681348082484307, 'Numerian'),
      Text(4.33678257060909, 0.7431802844944269, 'Severus II'),
      Text(3.745376722987502, 2.309145556889691, 'Constans I'),
      Text(2.5604798057379368, 3.578259795544228, 'Gratian'),
      Text(0.9148114866096122, 4.303849433236148, 'Valentinian II')],
     [Text(1.4695761589768238e-16, 2.4, '0.0%'),
      Text(-0.017332774245925817, 2.3999374106290645, '0.2%'),
      Text(-0.06932205687131243, 2.398998635354162, '0.5%'),
      Text(-0.15588650525228134, 2.3949320235614686, '0.7%'),
      Text(-0.2767100449346798, 2.3839948722747386, '0.9%'),
      Text(-0.43097265709727745, 2.3609876257266813, '1.1%'),
      Text(-0.6169791158399033, 2.3193397272968466, '1.4%'),
      Text(-0.8316971993641167, 2.2512840266323315, '1.6%'),
      Text(-1.070228373032911, 2.1481646188212227, '1.8%'),
      Text(-1.325250937087791, 2.000927273477957, '2.1%'),
      Text(-1.5864982875226585, 1.8008395774437187, '2.3%'),
      Text(-1.8403622244133373, 1.5404761870773573, '2.5%'),
      Text(-2.0697403732346786, 1.2149793362038603, '2.8%'),
      Text(-2.2542726177150265, 0.8235623625568627, '3.0%'),
      Text(-2.3711260181244604, 0.37116223699784073, '3.2%'),
      Text(-2.396480194029243, -0.12993336609801928, '3.4%'),
      Text(-2.3078226702815474, -0.658752246701708, '3.7%'),
      Text(-2.0870731614656943, -1.184958066215675, '3.9%'),
      Text(-1.724407541632379, -1.669256909634157, '4.1%'),
      Text(-1.2224452970416353, -2.0653395594286152, '4.4%'),
      Text(-0.6002128062738827, -2.3237350509868437, '4.6%'),
      Text(0.10396497867079052, -2.397747126619065, '4.8%'),
      Text(0.8316971730165633, -2.2512840363659707, '5.1%'),
      Text(1.50699889879386, -1.8678742781659832, '5.3%'),
      Text(2.0429327137709015, -1.2595340118490883, '5.5%'),
      Text(2.352821956731587, -0.4735280772264167, '5.7%'),
      Text(2.365517765786776, 0.40537106426968733, '6.0%'),
      Text(2.042932757993183, 1.2595339401216494, '6.2%'),
      Text(1.396625348584329, 1.9517780702968515, '6.4%'),
      Text(0.49898808360524294, 2.347554236310626, '6.7%')])




    
![png](output_180_2.png)
    



```python

```


```python
QUESTION 10 (#Create a scatter plot showing the relationship between the total revenue earned by arcades and the number of Computer Science PhDs awarded in the U.S. between 2000 and 2009.

Don't forget to label your axes!

Color each dot according to its year)
```


```python
SOLUTION
```


```python
#import the necessary library
```


```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
url = 'https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/4479952?X-Blackboard-Expiration=1650099600000&X-Blackboard-Signature=LcB0xSrs94cFdOACeoSTFolhBOhzwvGpZQdMjyyynKw%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27arcade-revenue-vs-cs-doctorates.csv&response-content-type=text%2Fcsv&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPb%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJIMEYCIQCQBHXy5XvDApNT5O0cIZ3syuJtcCbQuogbvcdZFiAzwAIhAMUqBc2J8Rkit4PXLISn10V%2BMsHmlNP9Bu3aq%2FG90h7DKoMECJ%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMNTU2OTAzODYxMzYxIgxyCZ2u0Ro37bwV39cq1wOs%2FDraLlzPWGsSvnl3hyn1o4g2scOttVHR69HT3FDnueTWIN00c7vpFNNZtwZw5fLZc9A90K11WlXXUlj1t71HLTyGiFm7VzxlfGM%2FGhhl7Fj7kkF%2Fl5c7a4e9ig73SYWcoZBMDXSQnhFTrUvzsI9u9VXSuPkB9EgIfqCPhaKZRjERpgORt92mqP8c66E5y%2BGv4HENk4D%2BYGxitF%2BlDtRFk%2FTGdJejoXXijtbVOYaGyEn3%2FyU4MZJF7drI7SgrD3NxML3V7MTSI2jV%2Fp3q%2BMUyRmxb1iOQAhp1THBwWxXBvxrpuxuD%2BWex6HqO4L0AimW7wH%2Fo47xYWJkIuBrC8rFdh425hLaWqv7eWn3axL8JErBHT0MD1QJTkYCBEwFhAJa%2BIs5vtKiIpXS%2F22z2Otgh5M6O4PySqlR3WFvOX03zPn0VszeKzIYHW%2BHYC%2BmHkssbPgZ1vAbQ0UGcl4CNAImDxXLbNbvgin3xcJzTfhB%2BRdvYzDRu3%2Fg85rrO2c9uMkE%2Fj%2FAwCVNTTk2ximR70NzkmJM%2FxZYQzWL%2Bq7uLvFL1oOuoZWgYdnXJ1yC%2FOfA2Bl%2FD6QDJDjnpLSvNLolZS%2BzO%2FydWkvjjjxxP3XaM0YtvN%2FgvIHiyi98w7LTpkgY6pAEdHJoM4oViN5fOINoudfSCDaZVlIeJOJRkns%2Bi8hzn%2BxBSUKIeNU8pH17AN7PS18Hi6furtm%2Ba11%2BEebb1u1HdDaE28lEzteDPuf6h7bMl65urzIEscjZNn%2FlYapOtSmP7lGHyMFjEDSeGpeqqr3pDvxPPRHYy5kvGV87CVMsyz2YkQTr1SOCkh88HytGtQUKVdZoeBOz4iVJADj0y6Kcru1K45Q%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T030000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRYZ7RPYTZI%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=a4d1136a0d9fa0e90daefadad2540cecc6356adbd341c41dd60acc0243b55af6'
```


```python
data = pd.read_csv('https://learn-us-east-1-prod-fleet01-xythos.content.blackboardcdn.com/blackboard.learn.xythos.prod/599c7a2702a96/4479952?X-Blackboard-Expiration=1650110400000&X-Blackboard-Signature=nLYpHJxyz7IjNWvHc9NGwUUXP7cbXYId77f%2F5ORnOlU%3D&X-Blackboard-Client-Id=100784&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27arcade-revenue-vs-cs-doctorates.csv&response-content-type=text%2Fcsv&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEPb%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJIMEYCIQCQBHXy5XvDApNT5O0cIZ3syuJtcCbQuogbvcdZFiAzwAIhAMUqBc2J8Rkit4PXLISn10V%2BMsHmlNP9Bu3aq%2FG90h7DKoMECJ%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMNTU2OTAzODYxMzYxIgxyCZ2u0Ro37bwV39cq1wOs%2FDraLlzPWGsSvnl3hyn1o4g2scOttVHR69HT3FDnueTWIN00c7vpFNNZtwZw5fLZc9A90K11WlXXUlj1t71HLTyGiFm7VzxlfGM%2FGhhl7Fj7kkF%2Fl5c7a4e9ig73SYWcoZBMDXSQnhFTrUvzsI9u9VXSuPkB9EgIfqCPhaKZRjERpgORt92mqP8c66E5y%2BGv4HENk4D%2BYGxitF%2BlDtRFk%2FTGdJejoXXijtbVOYaGyEn3%2FyU4MZJF7drI7SgrD3NxML3V7MTSI2jV%2Fp3q%2BMUyRmxb1iOQAhp1THBwWxXBvxrpuxuD%2BWex6HqO4L0AimW7wH%2Fo47xYWJkIuBrC8rFdh425hLaWqv7eWn3axL8JErBHT0MD1QJTkYCBEwFhAJa%2BIs5vtKiIpXS%2F22z2Otgh5M6O4PySqlR3WFvOX03zPn0VszeKzIYHW%2BHYC%2BmHkssbPgZ1vAbQ0UGcl4CNAImDxXLbNbvgin3xcJzTfhB%2BRdvYzDRu3%2Fg85rrO2c9uMkE%2Fj%2FAwCVNTTk2ximR70NzkmJM%2FxZYQzWL%2Bq7uLvFL1oOuoZWgYdnXJ1yC%2FOfA2Bl%2FD6QDJDjnpLSvNLolZS%2BzO%2FydWkvjjjxxP3XaM0YtvN%2FgvIHiyi98w7LTpkgY6pAEdHJoM4oViN5fOINoudfSCDaZVlIeJOJRkns%2Bi8hzn%2BxBSUKIeNU8pH17AN7PS18Hi6furtm%2Ba11%2BEebb1u1HdDaE28lEzteDPuf6h7bMl65urzIEscjZNn%2FlYapOtSmP7lGHyMFjEDSeGpeqqr3pDvxPPRHYy5kvGV87CVMsyz2YkQTr1SOCkh88HytGtQUKVdZoeBOz4iVJADj0y6Kcru1K45Q%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220416T060000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAYDKQORRYZ7RPYTZI%2F20220416%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=0e119161f6517e22a989832e879c58108a2ff41c6b1396c9b3f9f965cf65aaf0')
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Total Arcade Revenue (billions)</th>
      <th>Computer Science Doctorates Awarded (US)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2000</td>
      <td>1.196</td>
      <td>861</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2001</td>
      <td>1.176</td>
      <td>830</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2002</td>
      <td>1.269</td>
      <td>809</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2003</td>
      <td>1.240</td>
      <td>867</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2004</td>
      <td>1.307</td>
      <td>948</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(x="Total Arcade Revenue (billions)",y="Computer Science Doctorates Awarded (US)",c=data.Year,cmap="rainbow",data=data)

plt.xlabel('Total Arcade Revenue (billions)')

plt.ylabel('Computer Science Doctorates Awarded (US)')


plt.show()
```


    
![png](output_189_0.png)
    



```python

```


```python

```
